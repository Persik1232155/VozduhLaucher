package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
)

var javaMu sync.Mutex
var javaFound = map[int]string{} // major -> javaw path

func javaExeName() string {
	if runtime.GOOS == "windows" {
		return "javaw.exe"
	}
	return "java"
}
func javaProbeName() string {
	if runtime.GOOS == "windows" {
		return "java.exe"
	}
	return "java"
}

// javaMajorOf runs `java -version` and parses the major version.
func javaMajorOf(exe string) int {
	cmd := exec.Command(exe, "-version")
	hideWindow(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return 0
	}
	re := regexp.MustCompile(`version "([0-9]+)(?:\.([0-9]+))?`)
	m := re.FindStringSubmatch(string(out))
	if m == nil {
		return 0
	}
	major, _ := strconv.Atoi(m[1])
	if major == 1 && m[2] != "" { // 1.8 style
		major, _ = strconv.Atoi(m[2])
	}
	return major
}

// candidate dirs that may contain java installs
func javaSearchDirs() []string {
	var dirs []string
	if runtime.GOOS == "windows" {
		for _, base := range []string{os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)"), os.Getenv("LOCALAPPDATA")} {
			if base == "" {
				continue
			}
			for _, vendor := range []string{"Java", "Eclipse Adoptium", "Eclipse Foundation", "Microsoft", "Zulu", "Amazon Corretto", "BellSoft", "AdoptOpenJDK", "Semeru"} {
				dirs = append(dirs, filepath.Join(base, vendor))
			}
			dirs = append(dirs, filepath.Join(base, "Common Files", "Oracle", "Java"))
		}
		// minecraft launcher bundled runtimes
		if a := os.Getenv("LOCALAPPDATA"); a != "" {
			dirs = append(dirs, filepath.Join(a, "Packages", "Microsoft.4297127D64EC6_8wekyb3d8bbwe", "LocalCache", "Local", "runtime"))
		}
		if pf := os.Getenv("ProgramFiles(x86)"); pf != "" {
			dirs = append(dirs, filepath.Join(pf, "Minecraft Launcher", "runtime"))
		}
	}
	return dirs
}

// findSystemJava searches for an installed java of the exact major version.
func findSystemJava(major int) string {
	// our own downloads first
	own := filepath.Join(javaDir(), strconv.Itoa(major))
	if p := findJavawUnder(own, 3); p != "" {
		return p
	}
	// JAVA_HOME
	if jh := os.Getenv("JAVA_HOME"); jh != "" {
		p := filepath.Join(jh, "bin", javaProbeName())
		if javaMajorOf(p) == major {
			return preferJavaw(p)
		}
	}
	// PATH
	if p, err := exec.LookPath(javaProbeName()); err == nil {
		if javaMajorOf(p) == major {
			return preferJavaw(p)
		}
	}
	// common dirs (scan two levels: vendor/jdk-xx/bin/java.exe)
	for _, dir := range javaSearchDirs() {
		entries, err := os.ReadDir(dir)
		if err != nil {
			continue
		}
		for _, e := range entries {
			if !e.IsDir() {
				continue
			}
			p := filepath.Join(dir, e.Name(), "bin", javaProbeName())
			if _, err := os.Stat(p); err == nil {
				if javaMajorOf(p) == major {
					return preferJavaw(p)
				}
				continue
			}
			// one more level (e.g. runtime/java-runtime-gamma/windows-x64/java-runtime-gamma/bin)
			if q := findJavawUnder(filepath.Join(dir, e.Name()), 3); q != "" {
				if javaMajorOf(strings.Replace(q, javaExeName(), javaProbeName(), 1)) == major {
					return q
				}
			}
		}
	}
	return ""
}

func findJavawUnder(root string, depth int) string {
	if depth < 0 {
		return ""
	}
	p := filepath.Join(root, "bin", javaExeName())
	if _, err := os.Stat(p); err == nil {
		return p
	}
	entries, err := os.ReadDir(root)
	if err != nil {
		return ""
	}
	for _, e := range entries {
		if e.IsDir() {
			if q := findJavawUnder(filepath.Join(root, e.Name()), depth-1); q != "" {
				return q
			}
		}
	}
	return ""
}

func preferJavaw(javaExe string) string {
	if runtime.GOOS != "windows" {
		return javaExe
	}
	w := filepath.Join(filepath.Dir(javaExe), "javaw.exe")
	if _, err := os.Stat(w); err == nil {
		return w
	}
	return javaExe
}

// ensureJava returns a javaw path for the major version, downloading Temurin JRE if needed.
func ensureJava(vid string, major int) (string, error) {
	javaMu.Lock()
	defer javaMu.Unlock()
	if p, ok := javaFound[major]; ok {
		if _, err := os.Stat(p); err == nil {
			return p, nil
		}
		delete(javaFound, major)
	}
	if p := findSystemJava(major); p != "" {
		javaFound[major] = p
		return p, nil
	}
	// download from Adoptium
	reportProgress(vid, "java", 0, 0, strconv.Itoa(major))
	osName := "windows"
	if runtime.GOOS != "windows" {
		osName = "linux"
	}
	api := fmt.Sprintf("https://api.adoptium.net/v3/assets/latest/%d/hotspot?architecture=x64&image_type=jre&os=%s&vendor=eclipse", major, osName)
	var assets []struct {
		Binary struct {
			Package struct {
				Link string `json:"link"`
				Name string `json:"name"`
			} `json:"package"`
		} `json:"binary"`
	}
	if err := fetchJSON(api, &assets); err != nil {
		return "", err
	}
	if len(assets) == 0 {
		return "", fmt.Errorf("no Java %d build available", major)
	}
	link := assets[0].Binary.Package.Link
	archPath := filepath.Join(cacheDir(), "java-"+strconv.Itoa(major)+filepath.Ext(link))
	if err := downloadFile(link, archPath, ""); err != nil {
		return "", err
	}
	dest := filepath.Join(javaDir(), strconv.Itoa(major))
	os.MkdirAll(dest, 0o755)
	if strings.HasSuffix(link, ".zip") {
		if err := unzipFilter(archPath, dest, nil); err != nil {
			return "", err
		}
	} else {
		cmd := exec.Command("tar", "-xzf", archPath, "-C", dest)
		if out, err := cmd.CombinedOutput(); err != nil {
			return "", fmt.Errorf("extract java: %v %s", err, out)
		}
	}
	os.Remove(archPath)
	if p := findJavawUnder(dest, 3); p != "" {
		javaFound[major] = p
		return p, nil
	}
	return "", fmt.Errorf("java extract failed")
}
