package main

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

// VozduhanClient: an optional custom client shipped as a GitHub release zip
// containing a Fabric mod (.jar) and a native helper (.exe). It is never stored
// locally in the launcher — it is fetched from GitHub on demand and extracted
// into the target instance.

const vozduhanRepo = "Persik1232155/VozduhanClient"

// which loader/mc combinations offer the client
var vozduhanCompat = map[string][]string{
	"fabric": {"1.21.4"},
}

func vozduhanSupported(loader, mc string) bool {
	for _, m := range vozduhanCompat[loader] {
		if m == mc {
			return true
		}
	}
	return false
}

type ghAsset struct {
	Name        string `json:"name"`
	DownloadURL string `json:"browser_download_url"`
	Size        int64  `json:"size"`
}

type ghRelease struct {
	TagName string    `json:"tag_name"`
	Assets  []ghAsset `json:"assets"`
}

// vozduhanZipAsset finds the .zip asset of the latest release.
func vozduhanZipAsset() (*ghAsset, string, error) {
	var rel ghRelease
	if err := fetchJSON("https://api.github.com/repos/"+vozduhanRepo+"/releases/latest", &rel); err != nil {
		return nil, "", err
	}
	for i := range rel.Assets {
		if strings.HasSuffix(strings.ToLower(rel.Assets[i].Name), ".zip") {
			return &rel.Assets[i], rel.TagName, nil
		}
	}
	// fall back to any asset if there's no explicit zip
	if len(rel.Assets) > 0 {
		return &rel.Assets[0], rel.TagName, nil
	}
	return nil, "", fmt.Errorf("no release assets found")
}

// installVozduhanClient downloads the release zip and extracts it into the
// instance: .jar -> mods/, .exe -> instance root, everything else preserved.
func installVozduhanClient(vid string) {
	v := versionSnapshot(vid)
	if v == nil {
		return
	}
	reportState(vid, "installing", "")
	err := func() error {
		reportProgress(vid, "client", 0, 0, "release")
		asset, tag, err := vozduhanZipAsset()
		if err != nil {
			return err
		}
		zipPath := filepath.Join(cacheDir(), "vozduhanclient-"+tag+".zip")
		if err := downloadFile(asset.DownloadURL, zipPath, ""); err != nil {
			return err
		}
		inst := instanceDir(v)
		modsDir := filepath.Join(inst, "mods")
		os.MkdirAll(modsDir, 0o755)

		// helper .exe lives here, exactly where the Fabric mod looks for it
		npDir := filepath.Join(inst, "config", "vozduhan", "NowPlayingHelper")

		r, err := zip.OpenReader(zipPath)
		if err != nil {
			return err
		}
		defer r.Close()
		reportProgress(vid, "client", 0, len(r.File), "extract")
		done := 0
		for _, f := range r.File {
			if f.FileInfo().IsDir() {
				continue
			}
			name := f.Name
			if strings.Contains(name, "..") {
				continue
			}
			base := filepath.Base(name)
			low := strings.ToLower(base)
			var dst string
			switch {
			case strings.HasSuffix(low, ".jar"):
				dst = filepath.Join(modsDir, base)
			case strings.HasSuffix(low, ".exe"):
				// free a possibly-running helper before overwriting
				killImage(base)
				dst = filepath.Join(npDir, base)
			default:
				// preserve any other file at its zip-relative path inside the instance
				dst = filepath.Join(inst, filepath.FromSlash(name))
			}
			if err := extractZipFile(f, dst); err != nil {
				return err
			}
			done++
			reportProgress(vid, "client", done, len(r.File), "extract")
		}

		// the client is a Fabric mod: make sure Fabric API is present, otherwise
		// it won't load. Skip if the zip already shipped it.
		if v.Loader == "fabric" && !hasFabricAPI(modsDir) {
			reportProgress(vid, "client", 0, 0, "fabric-api")
			mrInstall(v, "fabric-api", "mod") // best-effort
		}
		return nil
	}()
	if err != nil {
		reportState(vid, "error", "VozduhanClient: "+err.Error())
		return
	}
	reportState(vid, "ready", "")
	pushStateAll()
}

func hasFabricAPI(modsDir string) bool {
	entries, _ := os.ReadDir(modsDir)
	for _, e := range entries {
		if strings.Contains(strings.ToLower(e.Name()), "fabric-api") {
			return true
		}
	}
	return false
}

func extractZipFile(f *zip.File, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	if _, err := io.Copy(out, rc); err != nil {
		return err
	}
	return nil
}
