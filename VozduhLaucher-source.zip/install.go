package main

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// progress reporting helper: phase in {"meta","files","java","loader","assets","done"}
var progThrottle sync.Map // vid -> *progGate

type progGate struct {
	mu   sync.Mutex
	last time.Time
	pct  int
}

func reportProgress(vid, phase string, cur, total int, msg string) {
	gi, _ := progThrottle.LoadOrStore(vid, &progGate{})
	g := gi.(*progGate)
	g.mu.Lock()
	pct := -1
	if total > 0 {
		pct = cur * 100 / total
	}
	if total > 0 && cur != total && pct == g.pct && time.Since(g.last) < 250*time.Millisecond {
		g.mu.Unlock()
		return
	}
	g.last = time.Now()
	g.pct = pct
	g.mu.Unlock()
	broadcast(map[string]any{"type": "progress", "vid": vid, "phase": phase, "cur": cur, "total": total, "msg": msg})
}

func reportState(vid, state, msg string) {
	setRunState(vid, state)
	broadcast(map[string]any{"type": "state", "vid": vid, "state": state, "msg": msg})
}

// installVanillaJSON ensures versions/<mc>/<mc>.json (+jar entry) present. Returns json id.
func installVanillaJSON(mc string) (string, error) {
	url, sha, err := manifestEntry(mc)
	if err != nil {
		return "", err
	}
	p := filepath.Join(versionsDir(), mc, mc+".json")
	if err := downloadFile(url, p, sha); err != nil {
		return "", err
	}
	return mc, nil
}

// ensureFiles downloads client jar, libraries, assets for a resolved version. Also used by "fix".
func ensureFiles(vid, versionID string) error {
	eff, err := resolveVersion(versionID)
	if err != nil {
		return err
	}
	var jobs []dlJob

	// client jar: stored at versions/<base>/<base>.jar where base = root of inherits chain with downloads
	baseID := baseVanillaID(versionID)
	if eff.Downloads != nil {
		if c, ok := eff.Downloads["client"]; ok && c.URL != "" {
			jobs = append(jobs, dlJob{URL: c.URL, Path: clientJarPath(baseID), SHA: c.SHA1, Size: c.Size})
		}
	}
	libJobs, _, _ := libraryJobs(eff)
	jobs = append(jobs, libJobs...)

	// logging config
	if lc, ok := eff.Logging["client"]; ok && lc.File.URL != "" {
		jobs = append(jobs, dlJob{URL: lc.File.URL, Path: filepath.Join(assetsDir(), "log_configs", lc.File.ID), SHA: lc.File.SHA1})
	}

	reportProgress(vid, "files", 0, len(jobs), "")
	if err := downloadAll(jobs, 14, func(done, total int) {
		reportProgress(vid, "files", done, total, "")
	}); err != nil {
		return err
	}

	// assets
	if eff.AssetIndex != nil {
		idxPath := filepath.Join(assetsDir(), "indexes", eff.AssetIndex.ID+".json")
		if err := downloadFile(eff.AssetIndex.URL, idxPath, eff.AssetIndex.SHA1); err != nil {
			return err
		}
		b, err := os.ReadFile(idxPath)
		if err != nil {
			return err
		}
		var idx struct {
			Objects       map[string]struct {
				Hash string `json:"hash"`
				Size int64  `json:"size"`
			} `json:"objects"`
			Virtual       bool `json:"virtual"`
			MapToResources bool `json:"map_to_resources"`
		}
		if err := json.Unmarshal(b, &idx); err != nil {
			return err
		}
		var ajobs []dlJob
		for name, o := range idx.Objects {
			sub := o.Hash[:2] + "/" + o.Hash
			p := filepath.Join(assetsDir(), "objects", filepath.FromSlash(sub))
			ajobs = append(ajobs, dlJob{URL: "https://resources.download.minecraft.net/" + sub, Path: p, SHA: o.Hash, Size: o.Size})
			_ = name
		}
		reportProgress(vid, "assets", 0, len(ajobs), "")
		if err := downloadAll(ajobs, 20, func(done, total int) {
			reportProgress(vid, "assets", done, total, "")
		}); err != nil {
			return err
		}
		// legacy virtual assets
		if idx.Virtual || idx.MapToResources {
			vdir := filepath.Join(assetsDir(), "virtual", eff.AssetIndex.ID)
			for name, o := range idx.Objects {
				src := filepath.Join(assetsDir(), "objects", o.Hash[:2], o.Hash)
				dst := filepath.Join(vdir, filepath.FromSlash(name))
				if _, err := os.Stat(dst); err != nil {
					os.MkdirAll(filepath.Dir(dst), 0o755)
					if data, err := os.ReadFile(src); err == nil {
						os.WriteFile(dst, data, 0o644)
					}
				}
			}
		}
	}
	return nil
}

func baseVanillaID(versionID string) string {
	cur := versionID
	for i := 0; i < 8; i++ {
		v, err := readVersionJSON(cur)
		if err != nil {
			return cur
		}
		if v.InheritsFrom == "" {
			return cur
		}
		cur = v.InheritsFrom
	}
	return cur
}

func clientJarPath(baseID string) string {
	return filepath.Join(versionsDir(), baseID, baseID+".jar")
}

// ---------- loader installs ----------

// installLoader sets up version json for the loader and returns the launch version id.
func installLoader(vid, loader, mc string) (string, error) {
	reportProgress(vid, "meta", 0, 0, "")
	if _, err := installVanillaJSON(mc); err != nil {
		return "", err
	}
	switch loader {
	case "vanilla":
		return mc, nil
	case "fabric":
		return installFabricLike(mc,
			"https://meta.fabricmc.net/v2/versions/loader/"+mc,
			"https://meta.fabricmc.net/v2/versions/loader/%s/%s/profile/json")
	case "quilt":
		return installFabricLike(mc,
			"https://meta.quiltmc.org/v3/versions/loader/"+mc,
			"https://meta.quiltmc.org/v3/versions/loader/%s/%s/profile/json")
	case "forge":
		return installForgeLike(vid, mc, "forge")
	case "neoforge":
		return installForgeLike(vid, mc, "neoforge")
	case "liteloader":
		return installLiteLoader(mc)
	}
	return "", fmt.Errorf("unknown loader")
}

func installFabricLike(mc, loadersURL, profileTpl string) (string, error) {
	var loaders []struct {
		Loader struct {
			Version string `json:"version"`
			Stable  bool   `json:"stable"`
		} `json:"loader"`
	}
	if err := fetchJSON(loadersURL, &loaders); err != nil {
		return "", err
	}
	if len(loaders) == 0 {
		return "", fmt.Errorf("loader not available for %s", mc)
	}
	lv := loaders[0].Loader.Version
	for _, l := range loaders {
		if l.Loader.Stable {
			lv = l.Loader.Version
			break
		}
	}
	url := fmt.Sprintf(profileTpl, mc, lv)
	b, err := fetchBytes(url)
	if err != nil {
		return "", err
	}
	var prof struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(b, &prof); err != nil || prof.ID == "" {
		return "", fmt.Errorf("bad loader profile")
	}
	p := filepath.Join(versionsDir(), prof.ID, prof.ID+".json")
	os.MkdirAll(filepath.Dir(p), 0o755)
	if err := os.WriteFile(p, b, 0o644); err != nil {
		return "", err
	}
	return prof.ID, nil
}

// Forge / NeoForge: download official installer and run it headless with Java.
func installForgeLike(vid, mc, kind string) (string, error) {
	var installerURL, marker string
	if kind == "forge" {
		fv, err := forgeLatestFor(mc)
		if err != nil {
			return "", err
		}
		installerURL = fmt.Sprintf("https://maven.minecraftforge.net/net/minecraftforge/forge/%s/forge-%s-installer.jar", fv, fv)
		marker = fv
	} else {
		nv, err := neoforgeLatestFor(mc)
		if err != nil {
			return "", err
		}
		installerURL = fmt.Sprintf("https://maven.neoforged.net/releases/net/neoforged/neoforge/%s/neoforge-%s-installer.jar", nv, nv)
		marker = nv
	}

	// If already installed, reuse
	if id := findInstalledLoaderVersion(kind, mc, marker); id != "" {
		return id, nil
	}

	reportProgress(vid, "loader", 0, 0, "installer")
	instPath := filepath.Join(cacheDir(), kind+"-"+marker+"-installer.jar")
	if err := downloadFile(installerURL, instPath, ""); err != nil {
		return "", err
	}

	// Java needed to run the installer: use the version's required java
	eff, err := resolveVersion(mc)
	if err != nil {
		return "", err
	}
	major := 8
	if eff.JavaVersion != nil && eff.JavaVersion.MajorVersion > 0 {
		major = eff.JavaVersion.MajorVersion
	}
	javaExe, err := ensureJava(vid, major)
	if err != nil {
		return "", err
	}

	// forge installer requires launcher_profiles.json in target dir
	lp := filepath.Join(dataDir(), "launcher_profiles.json")
	if _, err := os.Stat(lp); err != nil {
		os.MkdirAll(dataDir(), 0o755)
		os.WriteFile(lp, []byte(`{"profiles":{},"settings":{},"version":3}`), 0o644)
	}
	before := listVersionDirs()
	reportProgress(vid, "loader", 0, 0, "run")
	cmd := exec.Command(javaExe, "-jar", instPath, "--installClient", dataDir())
	cmd.Dir = cacheDir()
	hideWindow(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		tail := string(out)
		if len(tail) > 400 {
			tail = tail[len(tail)-400:]
		}
		return "", fmt.Errorf("%s installer failed: %v %s", kind, err, tail)
	}
	after := listVersionDirs()
	var created string
	for d := range after {
		if !before[d] {
			// prefer dirs mentioning forge/neoforge
			ld := strings.ToLower(d)
			if strings.Contains(ld, "forge") {
				created = d
				break
			}
			if created == "" {
				created = d
			}
		}
	}
	if created == "" {
		if id := findInstalledLoaderVersion(kind, mc, marker); id != "" {
			return id, nil
		}
		return "", fmt.Errorf("%s installer produced no version", kind)
	}
	os.Remove(instPath)
	return created, nil
}

func listVersionDirs() map[string]bool {
	out := map[string]bool{}
	entries, _ := os.ReadDir(versionsDir())
	for _, e := range entries {
		if e.IsDir() {
			if _, err := os.Stat(filepath.Join(versionsDir(), e.Name(), e.Name()+".json")); err == nil {
				out[e.Name()] = true
			}
		}
	}
	return out
}

func findInstalledLoaderVersion(kind, mc, marker string) string {
	for d := range listVersionDirs() {
		ld := strings.ToLower(d)
		if kind == "forge" && strings.Contains(ld, "forge") && !strings.Contains(ld, "neoforge") &&
			(strings.Contains(d, marker) || (strings.Contains(d, mc) && strings.Contains(d, strings.TrimPrefix(marker, mc+"-")))) {
			return d
		}
		if kind == "neoforge" && strings.Contains(ld, "neoforge") && strings.Contains(d, marker) {
			return d
		}
	}
	return ""
}

func installLiteLoader(mc string) (string, error) {
	meta, err := liteloaderAll()
	if err != nil {
		return "", err
	}
	entry, ok := meta.Versions[mc]
	if !ok || entry.Artefacts == nil {
		return "", fmt.Errorf("LiteLoader not available for %s", mc)
	}
	art, ok := entry.Artefacts["com.mumfrey:liteloader"]
	if !ok {
		return "", fmt.Errorf("LiteLoader not available for %s", mc)
	}
	latest, ok := art["latest"]
	if !ok {
		for _, v := range art {
			latest = v
			break
		}
	}
	if latest.Version == "" {
		latest.Version = mc
	}
	tweak := latest.TweakClass
	if tweak == "" {
		tweak = "com.mumfrey.liteloader.launch.LiteLoaderTweaker"
	}
	repo := entry.Repo.URL
	if repo == "" {
		repo = "https://repo.mumfrey.com/content/repositories/liteloader/"
	}
	repo = strings.Replace(repo, "http://", "https://", 1)
	id := mc + "-LiteLoader" + mc
	vj := map[string]any{
		"id":           id,
		"inheritsFrom": mc,
		"type":         "release",
		"mainClass":    "net.minecraft.launchwrapper.Launch",
		"minecraftArguments": "--username ${auth_player_name} --version ${version_name} --gameDir ${game_directory} " +
			"--assetsDir ${assets_root} --assetIndex ${assets_index_name} --uuid ${auth_uuid} " +
			"--accessToken ${auth_access_token} --userType ${user_type} --tweakClass " + tweak,
		"libraries": []map[string]any{
			{"name": "com.mumfrey:liteloader:" + latest.Version, "url": repo},
			{"name": "net.minecraft:launchwrapper:1.12"},
		},
	}
	b, _ := json.MarshalIndent(vj, "", "  ")
	p := filepath.Join(versionsDir(), id, id+".json")
	os.MkdirAll(filepath.Dir(p), 0o755)
	if err := os.WriteFile(p, b, 0o644); err != nil {
		return "", err
	}
	return id, nil
}

// ---------- full install of a new version tile ----------

func doInstallVersion(vid string, withClient bool) {
	v := versionSnapshot(vid)
	if v == nil {
		return
	}
	reportState(vid, "installing", "")
	verID, err := installLoader(vid, v.Loader, v.MC)
	if err != nil {
		reportState(vid, "error", err.Error())
		return
	}
	cfgMu.Lock()
	if _, _, vv := findVersionLocked(vid); vv != nil {
		vv.VersionID = verID
		saveConfigLocked()
	}
	cfgMu.Unlock()

	if err := ensureFiles(vid, verID); err != nil {
		reportState(vid, "error", err.Error())
		return
	}
	// java ahead of time
	eff, err := resolveVersion(verID)
	if err == nil {
		major := 8
		if eff.JavaVersion != nil && eff.JavaVersion.MajorVersion > 0 {
			major = eff.JavaVersion.MajorVersion
		}
		if _, err := ensureJava(vid, major); err != nil {
			reportState(vid, "error", "Java: "+err.Error())
			return
		}
	}
	// instance dir
	os.MkdirAll(filepath.Join(instancesDir(), v.Name, "mods"), 0o755)
	os.MkdirAll(filepath.Join(instancesDir(), v.Name, "resourcepacks"), 0o755)
	reportState(vid, "ready", "")
	pushStateAll()

	if withClient {
		installVozduhanClient(vid)
	}
}
