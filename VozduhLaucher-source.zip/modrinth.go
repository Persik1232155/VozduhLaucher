package main

import (
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const modrinthAPI = "https://api.modrinth.com/v2"

type mrHit struct {
	ProjectID   string   `json:"project_id"`
	Slug        string   `json:"slug"`
	Title       string   `json:"title"`
	Description string   `json:"description"`
	IconURL     string   `json:"icon_url"`
	Downloads   int64    `json:"downloads"`
	Follows     int64    `json:"follows"`
	Author      string   `json:"author"`
	ProjectType string   `json:"project_type"`
	Versions    []string `json:"versions"`
	Categories  []string `json:"categories"`
	Gallery     []string `json:"gallery"`
}

type mrSearchResult struct {
	Hits []mrHit `json:"hits"`
}

type mrVersion struct {
	ID            string   `json:"id"`
	ProjectID     string   `json:"project_id"`
	GameVersions  []string `json:"game_versions"`
	Loaders       []string `json:"loaders"`
	VersionNumber string   `json:"version_number"`
	Files         []struct {
		URL      string `json:"url"`
		Filename string `json:"filename"`
		Primary  bool   `json:"primary"`
		Hashes   struct {
			SHA1 string `json:"sha1"`
		} `json:"hashes"`
	} `json:"files"`
	Dependencies []struct {
		ProjectID      string `json:"project_id"`
		DependencyType string `json:"dependency_type"`
	} `json:"dependencies"`
}

// content type -> modrinth facets + destination folder
func mrTypeInfo(ctype, loader string) (facets [][]string, folder string, useLoader bool) {
	switch ctype {
	case "mod":
		return [][]string{{"project_type:mod"}}, "mods", true
	case "resourcepack":
		return [][]string{{"project_type:resourcepack"}}, "resourcepacks", false
	case "shader":
		return [][]string{{"project_type:shader"}}, "shaderpacks", false
	case "datapack":
		return [][]string{{"project_type:mod"}, {"categories:datapack"}}, "datapacks", false
	}
	return [][]string{{"project_type:mod"}}, "mods", true
}

func mrSearch(query, ctype, mc, loader string) (*mrSearchResult, error) {
	facets, _, useLoader := mrTypeInfo(ctype, loader)
	if mc != "" {
		facets = append(facets, []string{"versions:" + mc})
	}
	if useLoader && loader != "" && loader != "vanilla" {
		facets = append(facets, []string{"categories:" + loader})
	}
	fb, _ := json.Marshal(facets)
	u := fmt.Sprintf("%s/search?query=%s&limit=30&index=relevance&facets=%s",
		modrinthAPI, url.QueryEscape(query), url.QueryEscape(string(fb)))
	var res mrSearchResult
	if err := fetchJSON(u, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// ---------- popular feed (Home marquee + Game side-rail) ----------

var popularCache struct {
	sync.Mutex
	hits []mrHit
	at   time.Time
}

func mrPopular() ([]mrHit, error) {
	popularCache.Lock()
	defer popularCache.Unlock()
	if popularCache.hits != nil && time.Since(popularCache.at) < 30*time.Minute {
		return popularCache.hits, nil
	}
	fetch := func(ptype string, limit int) []mrHit {
		fb, _ := json.Marshal([][]string{{"project_type:" + ptype}})
		u := fmt.Sprintf("%s/search?limit=%d&index=follows&facets=%s", modrinthAPI, limit, url.QueryEscape(string(fb)))
		var res mrSearchResult
		if err := fetchJSON(u, &res); err != nil {
			return nil
		}
		for i := range res.Hits {
			if res.Hits[i].ProjectType == "" {
				res.Hits[i].ProjectType = ptype
			}
		}
		return res.Hits
	}
	mods := fetch("mod", 16)
	packs := fetch("resourcepack", 10)
	shaders := fetch("shader", 6)
	if mods == nil && packs == nil && shaders == nil {
		return nil, fmt.Errorf("modrinth unreachable")
	}
	// interleave for variety
	var out []mrHit
	maxLen := len(mods)
	if len(packs) > maxLen {
		maxLen = len(packs)
	}
	if len(shaders) > maxLen {
		maxLen = len(shaders)
	}
	for i := 0; i < maxLen; i++ {
		if i < len(mods) {
			out = append(out, mods[i])
		}
		if i < len(packs) {
			out = append(out, packs[i])
		}
		if i < len(shaders) {
			out = append(out, shaders[i])
		}
	}
	popularCache.hits = out
	popularCache.at = time.Now()
	return out, nil
}

// ---------- project info (for install target picker) ----------

type mrProject struct {
	ID           string   `json:"id"`
	Slug         string   `json:"slug"`
	Title        string   `json:"title"`
	ProjectType  string   `json:"project_type"`
	Loaders      []string `json:"loaders"`
	GameVersions []string `json:"game_versions"`
	IconURL      string   `json:"icon_url"`
}

func mrProjectInfo(id string) (*mrProject, error) {
	var p mrProject
	if err := fetchJSON(modrinthAPI+"/project/"+url.PathEscape(id), &p); err != nil {
		return nil, err
	}
	return &p, nil
}

// ---------- installed content listing ----------

type installedItem struct {
	File       string `json:"file"`
	Title      string `json:"title"`
	IconURL    string `json:"iconUrl"`
	ProjectID  string `json:"projectId"`
	VersionNum string `json:"versionNum"`
	HasUpdate  bool   `json:"hasUpdate"`
	Enabled    bool   `json:"enabled"`
}

func contentFolder(ctype string) string {
	switch ctype {
	case "resourcepack":
		return "resourcepacks"
	case "shader":
		return "shaderpacks"
	case "datapack":
		return "datapacks"
	}
	return "mods"
}

func contentExts(ctype string) []string {
	if ctype == "resourcepack" || ctype == "shader" || ctype == "datapack" {
		return []string{".zip", ".zip.disabled"}
	}
	return []string{".jar", ".jar.disabled"}
}

func listInstalled(v *Version, ctype string) ([]installedItem, error) {
	dir := filepath.Join(instanceDir(v), contentFolder(ctype))
	entries, err := os.ReadDir(dir)
	if err != nil {
		return []installedItem{}, nil
	}
	exts := contentExts(ctype)
	var items []installedItem
	hashToIdx := map[string]int{}
	var hashes []string
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		name := e.Name()
		low := strings.ToLower(name)
		ok := false
		for _, ext := range exts {
			if strings.HasSuffix(low, ext) {
				ok = true
				break
			}
		}
		if !ok {
			continue
		}
		enabled := !strings.HasSuffix(low, ".disabled")
		it := installedItem{File: name, Title: name, Enabled: enabled}
		if h, err := sha1File(filepath.Join(dir, name)); err == nil {
			hashToIdx[h] = len(items)
			hashes = append(hashes, h)
		}
		items = append(items, it)
	}
	if len(hashes) == 0 {
		return items, nil
	}
	// enrich via Modrinth: which project each file belongs to
	var byHash map[string]mrVersion
	if err := postJSON(modrinthAPI+"/version_files", map[string]any{"hashes": hashes, "algorithm": "sha1"}, &byHash); err == nil {
		projIDs := map[string]bool{}
		for h, mv := range byHash {
			if idx, ok := hashToIdx[h]; ok {
				items[idx].ProjectID = mv.ProjectID
				items[idx].VersionNum = mv.VersionNumber
				projIDs[mv.ProjectID] = true
			}
		}
		// project titles + icons
		if len(projIDs) > 0 {
			var ids []string
			for id := range projIDs {
				ids = append(ids, id)
			}
			idsJSON, _ := json.Marshal(ids)
			var projs []mrProject
			if err := fetchJSON(modrinthAPI+"/projects?ids="+url.QueryEscape(string(idsJSON)), &projs); err == nil {
				pmap := map[string]mrProject{}
				for _, p := range projs {
					pmap[p.ID] = p
				}
				for i := range items {
					if p, ok := pmap[items[i].ProjectID]; ok {
						items[i].Title = p.Title
						items[i].IconURL = p.IconURL
					}
				}
			}
		}
	}
	// updates available?
	var updates map[string]mrVersion
	if postJSON(modrinthAPI+"/version_files/update", map[string]any{
		"hashes": hashes, "algorithm": "sha1",
		"loaders": []string{v.Loader}, "game_versions": []string{v.MC},
	}, &updates) == nil {
		for h, mv := range updates {
			if idx, ok := hashToIdx[h]; ok {
				for _, f := range mv.Files {
					if f.Hashes.SHA1 != "" && f.Hashes.SHA1 != h {
						items[idx].HasUpdate = true
					}
				}
			}
		}
	}
	return items, nil
}

func deleteInstalled(v *Version, ctype, file string) error {
	if strings.Contains(file, "/") || strings.Contains(file, "\\") || strings.Contains(file, "..") {
		return fmt.Errorf("bad name")
	}
	return os.Remove(filepath.Join(instanceDir(v), contentFolder(ctype), file))
}

func updateInstalled(v *Version, ctype, file string) error {
	if strings.Contains(file, "/") || strings.Contains(file, "\\") || strings.Contains(file, "..") {
		return fmt.Errorf("bad name")
	}
	dir := filepath.Join(instanceDir(v), contentFolder(ctype))
	p := filepath.Join(dir, file)
	h, err := sha1File(p)
	if err != nil {
		return err
	}
	var updates map[string]mrVersion
	if err := postJSON(modrinthAPI+"/version_files/update", map[string]any{
		"hashes": []string{h}, "algorithm": "sha1",
		"loaders": []string{v.Loader}, "game_versions": []string{v.MC},
	}, &updates); err != nil {
		return err
	}
	mv, ok := updates[h]
	if !ok {
		return fmt.Errorf("no update")
	}
	for _, f := range mv.Files {
		if !f.Primary && len(mv.Files) > 1 {
			continue
		}
		if f.Hashes.SHA1 == h {
			return nil // already latest
		}
		np := filepath.Join(dir, f.Filename)
		if err := downloadFile(f.URL, np, f.Hashes.SHA1); err != nil {
			return err
		}
		if !strings.EqualFold(np, p) {
			os.Remove(p)
		}
		return nil
	}
	return nil
}

// pick best version of a project for mc+loader
func mrBestVersion(projectID, ctype, mc, loader string) (*mrVersion, error) {
	_, _, useLoader := mrTypeInfo(ctype, loader)
	// Query params must be URL-encoded JSON arrays, otherwise Modrinth returns HTTP 400.
	params := url.Values{}
	gv, _ := json.Marshal([]string{mc})
	params.Set("game_versions", string(gv))
	if ctype == "datapack" {
		ld, _ := json.Marshal([]string{"datapack"})
		params.Set("loaders", string(ld))
	} else if useLoader && loader != "" && loader != "vanilla" {
		ld, _ := json.Marshal([]string{loader})
		params.Set("loaders", string(ld))
	}
	q := fmt.Sprintf("%s/project/%s/version?%s", modrinthAPI, url.PathEscape(projectID), params.Encode())

	var vers []mrVersion
	if err := fetchJSON(q, &vers); err != nil {
		return nil, err
	}
	if len(vers) > 0 {
		return &vers[0], nil
	}
	// Fallback: some projects tag versions loosely — retry without the loader filter
	// and pick the newest version that lists this game version.
	if useLoader {
		params.Del("loaders")
		q2 := fmt.Sprintf("%s/project/%s/version?%s", modrinthAPI, url.PathEscape(projectID), params.Encode())
		var all []mrVersion
		if err := fetchJSON(q2, &all); err == nil {
			for i := range all {
				for _, l := range all[i].Loaders {
					if strings.EqualFold(l, loader) {
						return &all[i], nil
					}
				}
			}
		}
	}
	return nil, fmt.Errorf("no compatible version")
}

// install project into instance; resolves required dependencies for mods
func mrInstall(v *Version, projectID, ctype string) error {
	_, folder, _ := mrTypeInfo(ctype, v.Loader)
	dest := filepath.Join(instanceDir(v), folder)
	os.MkdirAll(dest, 0o755)
	installed := map[string]bool{}
	return mrInstallRec(v, projectID, ctype, dest, installed, 0)
}

func mrInstallRec(v *Version, projectID, ctype, dest string, installed map[string]bool, depth int) error {
	if depth > 4 || installed[projectID] {
		return nil
	}
	installed[projectID] = true
	mv, err := mrBestVersion(projectID, ctype, v.MC, v.Loader)
	if err != nil {
		if depth > 0 {
			return nil // optional/unavailable dep: skip silently
		}
		return err
	}
	for _, f := range mv.Files {
		if !f.Primary && len(mv.Files) > 1 {
			continue
		}
		if err := downloadFile(f.URL, filepath.Join(dest, f.Filename), f.Hashes.SHA1); err != nil {
			return err
		}
	}
	if ctype == "mod" {
		for _, d := range mv.Dependencies {
			if d.DependencyType == "required" && d.ProjectID != "" {
				mrInstallRec(v, "mod", d.ProjectID, dest, installed, depth+1)
			}
		}
	}
	return nil
}

// ---------- fix mods (like Modrinth "Fix instance") ----------

func fixInstance(vid string) {
	v := versionSnapshot(vid)
	if v == nil {
		return
	}
	reportState(vid, "installing", "")
	err := func() error {
		// 1. repair libraries/assets/client
		if v.VersionID != "" {
			if err := ensureFiles(vid, v.VersionID); err != nil {
				return err
			}
		}
		// 2. update mods + fetch missing required deps
		modsDir := filepath.Join(instanceDir(v), "mods")
		entries, _ := os.ReadDir(modsDir)
		var hashes []string
		hashToFile := map[string]string{}
		for _, e := range entries {
			if e.IsDir() || !strings.HasSuffix(strings.ToLower(e.Name()), ".jar") {
				continue
			}
			p := filepath.Join(modsDir, e.Name())
			h, err := sha1File(p)
			if err != nil {
				continue
			}
			hashes = append(hashes, h)
			hashToFile[h] = p
		}
		if len(hashes) == 0 {
			return nil
		}
		reportProgress(vid, "loader", 0, len(hashes), "mods")

		// latest matching versions for all hashes
		var updates map[string]mrVersion
		if err := postJSON(modrinthAPI+"/version_files/update", map[string]any{
			"hashes":        hashes,
			"algorithm":     "sha1",
			"loaders":       []string{v.Loader},
			"game_versions": []string{v.MC},
		}, &updates); err != nil {
			return err
		}
		done := 0
		needed := map[string]bool{} // required dep project ids
		have := map[string]bool{}   // project ids present
		for h, mv := range updates {
			have[mv.ProjectID] = true
			for _, d := range mv.Dependencies {
				if d.DependencyType == "required" && d.ProjectID != "" {
					needed[d.ProjectID] = true
				}
			}
			old := hashToFile[h]
			for _, f := range mv.Files {
				if !f.Primary && len(mv.Files) > 1 {
					continue
				}
				np := filepath.Join(modsDir, f.Filename)
				if f.Hashes.SHA1 == h {
					continue // already newest
				}
				if err := downloadFile(f.URL, np, f.Hashes.SHA1); err == nil {
					if old != "" && !strings.EqualFold(old, np) {
						os.Remove(old)
					}
				}
			}
			done++
			reportProgress(vid, "loader", done, len(hashes), "mods")
		}
		// install missing required deps
		installed := map[string]bool{}
		for pid := range have {
			installed[pid] = true
		}
		for pid := range needed {
			if !installed[pid] {
				mrInstallRec(v, "mod", pid, modsDir, installed, 1)
			}
		}
		return nil
	}()
	if err != nil {
		reportState(vid, "error", err.Error())
		return
	}
	reportState(vid, "ready", "")
}
