package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

// Local skins for offline mode: a tiny Yggdrasil-compatible server on 127.0.0.1
// injected into the game via authlib-injector (downloaded on demand).

var skinSrv struct {
	sync.Mutex
	port int
	key  *rsa.PrivateKey
}

func skinPath() string {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	if cfg.Skin == "" {
		return ""
	}
	return filepath.Join(launcherRoot(), cfg.Skin)
}

func skinKey() *rsa.PrivateKey {
	if skinSrv.key != nil {
		return skinSrv.key
	}
	kp := filepath.Join(launcherRoot(), "skinkey.pem")
	if b, err := os.ReadFile(kp); err == nil {
		if blk, _ := pem.Decode(b); blk != nil {
			if k, err := x509.ParsePKCS1PrivateKey(blk.Bytes); err == nil {
				skinSrv.key = k
				return k
			}
		}
	}
	k, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil
	}
	b := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(k)})
	os.WriteFile(kp, b, 0o600)
	skinSrv.key = k
	return k
}

func pubKeyPEM(k *rsa.PrivateKey) string {
	der, _ := x509.MarshalPKIXPublicKey(&k.PublicKey)
	return string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: der}))
}

func signSHA1RSA(k *rsa.PrivateKey, data []byte) string {
	h := sha1.Sum(data)
	sig, err := rsa.SignPKCS1v15(rand.Reader, k, crypto.SHA1, h[:])
	if err != nil {
		return ""
	}
	return base64.StdEncoding.EncodeToString(sig)
}

func startSkinServer() int {
	skinSrv.Lock()
	defer skinSrv.Unlock()
	if skinSrv.port != 0 {
		return skinSrv.port
	}
	k := skinKey()
	if k == nil {
		return 0
	}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0
	}
	skinSrv.port = ln.Addr().(*net.TCPAddr).Port
	mux := http.NewServeMux()

	writeJSON := func(w http.ResponseWriter, v any) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(v)
	}

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		writeJSON(w, map[string]any{
			"meta": map[string]any{
				"serverName":             "VozduhLaucher",
				"implementationName":     "vozduh-skin",
				"implementationVersion":  "1.0",
				"feature.non_email_login": true,
			},
			"skinDomains":        []string{"127.0.0.1", "localhost"},
			"signaturePublickey": pubKeyPEM(k),
		})
	})

	profileJSON := func(name string, unsigned bool) map[string]any {
		uuid := strings.ReplaceAll(offlineUUID(name), "-", "")
		port := skinSrv.port
		model := ""
		cfgMu.Lock()
		if cfg.SkinModel == "slim" {
			model = "slim"
		}
		cfgMu.Unlock()
		texEntry := map[string]any{"url": fmt.Sprintf("http://127.0.0.1:%d/skin.png", port)}
		if model != "" {
			texEntry["metadata"] = map[string]string{"model": model}
		}
		tex := map[string]any{
			"timestamp":   0,
			"profileId":   uuid,
			"profileName": name,
			"textures":    map[string]any{"SKIN": texEntry},
		}
		tb, _ := json.Marshal(tex)
		val := base64.StdEncoding.EncodeToString(tb)
		prop := map[string]any{"name": "textures", "value": val}
		if !unsigned {
			prop["signature"] = signSHA1RSA(k, []byte(val))
		}
		return map[string]any{"id": uuid, "name": name, "properties": []any{prop}}
	}

	mux.HandleFunc("/sessionserver/session/minecraft/profile/", func(w http.ResponseWriter, r *http.Request) {
		cfgMu.Lock()
		name := cfg.Nickname
		cfgMu.Unlock()
		unsigned := r.URL.Query().Get("unsigned") == "true"
		writeJSON(w, profileJSON(name, unsigned))
	})
	mux.HandleFunc("/api/profiles/minecraft", func(w http.ResponseWriter, r *http.Request) {
		var names []string
		json.NewDecoder(r.Body).Decode(&names)
		var out []map[string]any
		for _, n := range names {
			out = append(out, map[string]any{
				"id":   strings.ReplaceAll(offlineUUID(n), "-", ""),
				"name": n,
			})
		}
		writeJSON(w, out)
	})
	mux.HandleFunc("/sessionserver/session/minecraft/join", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNoContent)
	})
	mux.HandleFunc("/sessionserver/session/minecraft/hasJoined", func(w http.ResponseWriter, r *http.Request) {
		name := r.URL.Query().Get("username")
		writeJSON(w, profileJSON(name, false))
	})
	mux.HandleFunc("/skin.png", func(w http.ResponseWriter, r *http.Request) {
		p := skinPath()
		if p == "" {
			http.NotFound(w, r)
			return
		}
		http.ServeFile(w, r, p)
	})

	go http.Serve(ln, mux)
	return skinSrv.port
}

func authlibInjectorJar() string {
	jar := filepath.Join(launcherRoot(), "authlib-injector.jar")
	if _, err := os.Stat(jar); err == nil {
		return jar
	}
	var meta struct {
		DownloadURL string `json:"download_url"`
	}
	if err := fetchJSON("https://authlib-injector.yushi.moe/artifact/latest.json", &meta); err != nil || meta.DownloadURL == "" {
		return ""
	}
	if err := downloadFile(meta.DownloadURL, jar, ""); err != nil {
		return ""
	}
	return jar
}

// maybeSkinArgs returns JVM args enabling the local skin, or nil.
func maybeSkinArgs() []string {
	if skinPath() == "" {
		return nil
	}
	jar := authlibInjectorJar()
	if jar == "" {
		return nil
	}
	port := startSkinServer()
	if port == 0 {
		return nil
	}
	return []string{
		fmt.Sprintf("-javaagent:%s=http://127.0.0.1:%d", jar, port),
		"-Dauthlibinjector.side=client",
		"-Dauthlibinjector.disableHttpd",
	}
}
