//go:build !windows

package main

import (
	"fmt"
	"os/exec"
)

func hideWindow(cmd *exec.Cmd) {}

func openFolder(dir string) {
	exec.Command("xdg-open", dir).Start()
}

func killImage(name string) {}

func openWindow(url string) {
	fmt.Println("UI at:", url)
}

func runUINative(url string) bool { return false }

func focusExisting() bool { return false }

func makeDPIAware() {}
