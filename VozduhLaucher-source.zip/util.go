package main

import (
	"archive/zip"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

var httpClient = &http.Client{Timeout: 180 * time.Second}

func httpGet(url string) (*http.Response, error) {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "VozduhLaucher/1.0")
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode >= 400 {
		resp.Body.Close()
		return nil, fmt.Errorf("HTTP %d: %s", resp.StatusCode, url)
	}
	return resp, nil
}

func fetchBytes(url string) ([]byte, error) {
	resp, err := httpGet(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(resp.Body)
}

func fetchJSON(url string, v any) error {
	b, err := fetchBytes(url)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}

func postJSON(url string, body any, v any) error {
	b, _ := json.Marshal(body)
	req, err := http.NewRequest("POST", url, strings.NewReader(string(b)))
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "VozduhLaucher/1.0")
	req.Header.Set("Content-Type", "application/json")
	resp, err := httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return fmt.Errorf("HTTP %d: %s", resp.StatusCode, url)
	}
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if v != nil {
		return json.Unmarshal(data, v)
	}
	return nil
}

func sha1File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha1.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// downloadFile downloads url to path, verifying sha1 if given (skips if file already valid).
func downloadFile(url, path, sha string) error {
	if st, err := os.Stat(path); err == nil && st.Size() > 0 {
		if sha == "" {
			return nil
		}
		if got, err := sha1File(path); err == nil && got == sha {
			return nil
		}
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		lastErr = func() error {
			resp, err := httpGet(url)
			if err != nil {
				return err
			}
			defer resp.Body.Close()
			tmp := path + ".part"
			f, err := os.Create(tmp)
			if err != nil {
				return err
			}
			h := sha1.New()
			_, err = io.Copy(io.MultiWriter(f, h), resp.Body)
			f.Close()
			if err != nil {
				os.Remove(tmp)
				return err
			}
			if sha != "" && hex.EncodeToString(h.Sum(nil)) != sha {
				os.Remove(tmp)
				return fmt.Errorf("sha1 mismatch for %s", url)
			}
			return os.Rename(tmp, path)
		}()
		if lastErr == nil {
			return nil
		}
		time.Sleep(time.Duration(attempt+1) * time.Second)
	}
	return lastErr
}

type dlJob struct {
	URL, Path, SHA string
	Size           int64
}

// downloadAll downloads jobs concurrently, reporting progress via cb(done,total).
func downloadAll(jobs []dlJob, workers int, cb func(done, total int)) error {
	if len(jobs) == 0 {
		return nil
	}
	if workers <= 0 {
		workers = 12
	}
	var done int64
	total := len(jobs)
	ch := make(chan dlJob)
	var wg sync.WaitGroup
	var firstErr atomic.Value
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range ch {
				if firstErr.Load() != nil {
					continue
				}
				if err := downloadFile(j.URL, j.Path, j.SHA); err != nil {
					firstErr.CompareAndSwap(nil, err)
					continue
				}
				d := atomic.AddInt64(&done, 1)
				if cb != nil {
					cb(int(d), total)
				}
			}
		}()
	}
	for _, j := range jobs {
		ch <- j
	}
	close(ch)
	wg.Wait()
	if e := firstErr.Load(); e != nil {
		return e.(error)
	}
	return nil
}

// unzipFilter extracts zip to dir; if filter != nil only entries where filter(name) is true.
func unzipFilter(zipPath, dir string, filter func(string) bool) error {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer r.Close()
	for _, f := range r.File {
		name := f.Name
		if strings.Contains(name, "..") {
			continue
		}
		if filter != nil && !filter(name) {
			continue
		}
		dst := filepath.Join(dir, filepath.FromSlash(name))
		if f.FileInfo().IsDir() {
			os.MkdirAll(dst, 0o755)
			continue
		}
		if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
			return err
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.Create(dst)
		if err != nil {
			rc.Close()
			return err
		}
		_, err = io.Copy(out, rc)
		out.Close()
		rc.Close()
		if err != nil {
			return err
		}
		if f.Mode()&0o111 != 0 {
			os.Chmod(dst, 0o755)
		}
	}
	return nil
}

func sanitizeName(s string) string {
	s = strings.TrimSpace(s)
	bad := `<>:"/\|?*`
	out := strings.Map(func(r rune) rune {
		if strings.ContainsRune(bad, r) || r < 32 {
			return -1
		}
		return r
	}, s)
	if out == "" {
		out = "version"
	}
	return out
}

// uniqueInstanceName returns name, adding (2), (3)... if the folder already exists.
func uniqueInstanceName(base string) string {
	name := sanitizeName(base)
	try := name
	for i := 2; ; i++ {
		if _, err := os.Stat(filepath.Join(instancesDir(), try)); os.IsNotExist(err) {
			return try
		}
		try = fmt.Sprintf("%s (%d)", name, i)
	}
}
