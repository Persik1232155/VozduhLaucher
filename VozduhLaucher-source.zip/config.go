package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
	"sync"
)

// ---------- data model ----------

type Version struct {
	ID        string `json:"id"`        // internal uuid
	Name      string `json:"name"`      // display name == instance folder name
	Loader    string `json:"loader"`    // fabric|forge|neoforge|quilt|liteloader|vanilla
	MC        string `json:"mc"`        // minecraft version e.g. 1.21.1
	VersionID string `json:"versionId"` // id inside data/versions/
	RamMB      int   `json:"ramMB"`      // 0 => use global
	Image      string `json:"image"`     // custom image file name inside instance dir ("" = default)
	LastPlayed int64 `json:"lastPlayed"` // unix seconds, 0 = never
	PlaySecs   int64 `json:"playSecs"`   // total accumulated play time, seconds
}

type Field struct {
	ID       string    `json:"id"`
	Name     string    `json:"name"`
	Versions []Version `json:"versions"`
}

type Config struct {
	Nickname  string  `json:"nickname"`
	Theme     string  `json:"theme"` // black|dark|light
	RamMB     int     `json:"ramMB"`
	Skin      string  `json:"skin"`      // stored skin file name ("" = none)
	SkinModel string  `json:"skinModel"` // classic|slim
	SnowSpeed float64 `json:"snowSpeed"` // 0 (off) .. 3, default 1
	Fields    []Field `json:"fields"`
	FirstRun  bool    `json:"firstRun"`
}

var (
	cfg     Config
	cfgMu   sync.Mutex
	rootDir string
)

func newID() string {
	b := make([]byte, 8)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func launcherRoot() string {
	if rootDir != "" {
		return rootDir
	}
	if runtime.GOOS == "windows" {
		if a := os.Getenv("APPDATA"); a != "" {
			rootDir = filepath.Join(a, "VozduhLaucher")
		}
	}
	if rootDir == "" {
		home, _ := os.UserHomeDir()
		rootDir = filepath.Join(home, ".vozduhlaucher")
	}
	return rootDir
}

func dataDir() string      { return filepath.Join(launcherRoot(), "data") }
func versionsDir() string  { return filepath.Join(dataDir(), "versions") }
func librariesDir() string { return filepath.Join(dataDir(), "libraries") }
func assetsDir() string    { return filepath.Join(dataDir(), "assets") }
func javaDir() string      { return filepath.Join(launcherRoot(), "java") }
func instancesDir() string { return filepath.Join(launcherRoot(), "instances") }
func cacheDir() string     { return filepath.Join(launcherRoot(), "cache") }
func configPath() string   { return filepath.Join(launcherRoot(), "config.json") }

func instanceDir(v *Version) string { return filepath.Join(instancesDir(), v.Name) }

func defaultConfig() Config {
	return Config{
		Theme:     "black",
		RamMB:     4096,
		SkinModel: "classic",
		SnowSpeed: 1,
		FirstRun:  true,
		Fields: []Field{
			{ID: newID(), Name: "Universal", Versions: []Version{}},
			{ID: newID(), Name: "Pvp", Versions: []Version{}},
			{ID: newID(), Name: "Vanilla", Versions: []Version{}},
		},
	}
}

func loadConfig() {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	b, err := os.ReadFile(configPath())
	if err != nil {
		cfg = defaultConfig()
		return
	}
	if err := json.Unmarshal(b, &cfg); err != nil {
		cfg = defaultConfig()
		return
	}
	if cfg.Theme == "" {
		cfg.Theme = "black"
	}
	if cfg.RamMB == 0 {
		cfg.RamMB = 4096
	}
	if cfg.SnowSpeed == 0 {
		cfg.SnowSpeed = 1
	}
	if len(cfg.Fields) == 0 {
		cfg.Fields = defaultConfig().Fields
	}
	for i := range cfg.Fields {
		if cfg.Fields[i].Versions == nil {
			cfg.Fields[i].Versions = []Version{}
		}
	}
}

func saveConfigLocked() {
	os.MkdirAll(launcherRoot(), 0o755)
	b, _ := json.MarshalIndent(&cfg, "", "  ")
	os.WriteFile(configPath(), b, 0o644)
}

func saveConfig() {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	saveConfigLocked()
}

// findVersion returns pointers into cfg (call under cfgMu).
func findVersionLocked(vid string) (*Field, int, *Version) {
	for fi := range cfg.Fields {
		for vi := range cfg.Fields[fi].Versions {
			if cfg.Fields[fi].Versions[vi].ID == vid {
				return &cfg.Fields[fi], vi, &cfg.Fields[fi].Versions[vi]
			}
		}
	}
	return nil, -1, nil
}

// snapshot returns a deep copy of a version by id, or nil.
func versionSnapshot(vid string) *Version {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	_, _, v := findVersionLocked(vid)
	if v == nil {
		return nil
	}
	c := *v
	return &c
}
