//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"unsafe"

	webview2 "github.com/jchv/go-webview2"
)

func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000} // CREATE_NO_WINDOW
}

func openFolder(dir string) {
	exec.Command("explorer.exe", dir).Start()
}

// killImage best-effort terminates any running process with the given exe name
// so its file can be overwritten (e.g. NowPlayingHelper.exe left running).
func killImage(name string) {
	cmd := exec.Command("taskkill", "/F", "/IM", name)
	hideWindow(cmd)
	cmd.Run()
}

var (
	user32  = syscall.NewLazyDLL("user32.dll")
	shcore  = syscall.NewLazyDLL("shcore.dll")
	kernel  = syscall.NewLazyDLL("kernel32.dll")

	pGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	pGetWindowLongW     = user32.NewProc("GetWindowLongW")
	pSetWindowLongW     = user32.NewProc("SetWindowLongW")
	pSetWindowPos       = user32.NewProc("SetWindowPos")
	pGetWindowRect      = user32.NewProc("GetWindowRect")
	pFindWindowW        = user32.NewProc("FindWindowW")
	pSetForegroundWnd   = user32.NewProc("SetForegroundWindow")
	pShowWindow         = user32.NewProc("ShowWindow")
	pSendMessageW       = user32.NewProc("SendMessageW")
	pPostMessageW       = user32.NewProc("PostMessageW")
	pReleaseCapture     = user32.NewProc("ReleaseCapture")
	pMonitorFromWindow  = user32.NewProc("MonitorFromWindow")
	pGetMonitorInfoW    = user32.NewProc("GetMonitorInfoW")
	pSetProcessDpiCtx   = user32.NewProc("SetProcessDpiAwarenessContext")
	pSetProcessDPIAware = user32.NewProc("SetProcessDPIAware")
	pSetProcessDpiAware = shcore.NewProc("SetProcessDpiAwareness")
	pGetWindowLongPtrW  = user32.NewProc("GetWindowLongPtrW")
	pSetWindowLongPtrW  = user32.NewProc("SetWindowLongPtrW")
	pCallWindowProcW    = user32.NewProc("CallWindowProcW")
)

// GWLP_WNDPROC = -4
var gwlpWndProc = ^uintptr(3)

var origWndProc uintptr

// wndProc removes the non-client border (WM_NCCALCSIZE -> 0) so the WebView2
// fills the window edge-to-edge, while WS_THICKFRAME still allows resizing.
func wndProc(hwnd, msg, wparam, lparam uintptr) uintptr {
	if msg == 0x0083 && wparam != 0 { // WM_NCCALCSIZE
		return 0
	}
	r, _, _ := pCallWindowProcW.Call(origWndProc, hwnd, msg, wparam, lparam)
	return r
}

// GWL_STYLE = -16, sign-extended to native width.
var gwlStyle = ^uintptr(15)

const (
	wsPopup       = 0x80000000
	wsThickFrame  = 0x00040000
	wsMinimizeBox = 0x00020000
	wsMaximizeBox = 0x00010000
	wsSysMenu     = 0x00080000
	wsClipChild   = 0x02000000
	wsClipSib     = 0x04000000
	wsVisible     = 0x10000000

	swpFrameChanged = 0x0020
	swpNoZOrder     = 0x0004
	swpNoActivate   = 0x0010
	swpShow         = 0x0040

	wmNCLButtonDown = 0x00A1
	wmClose         = 0x0010
	htCaption       = 2

	swMinimize = 6
	swRestore  = 9

	monitorNearest = 2
)

// HT* codes for edge/corner resize via the system loop.
var htCodes = map[string]uintptr{
	"l": 10, "r": 11, "t": 12, "tl": 13, "tr": 14, "b": 15, "bl": 16, "br": 17,
}

type winRect struct{ Left, Top, Right, Bottom int32 }

type monitorInfo struct {
	CbSize    uint32
	RcMonitor winRect
	RcWork    winRect
	DwFlags   uint32
}

func screenSize() (int, int) {
	w, _, _ := pGetSystemMetrics.Call(0) // SM_CXSCREEN
	h, _, _ := pGetSystemMetrics.Call(1) // SM_CYSCREEN
	if w == 0 || h == 0 {
		return 1920, 1080
	}
	return int(w), int(h)
}

// makeDPIAware is a runtime backstop; the app manifest already declares PerMonitorV2.
func makeDPIAware() {
	if pSetProcessDpiCtx.Find() == nil {
		// DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4
		if r, _, _ := pSetProcessDpiCtx.Call(^uintptr(3)); r != 0 {
			return
		}
	}
	if pSetProcessDpiAware.Find() == nil {
		pSetProcessDpiAware.Call(2) // PROCESS_PER_MONITOR_DPI_AWARE
		return
	}
	if pSetProcessDPIAware.Find() == nil {
		pSetProcessDPIAware.Call()
	}
}

func monitorWork(hwnd uintptr) (work, full winRect) {
	mon, _, _ := pMonitorFromWindow.Call(hwnd, monitorNearest)
	var mi monitorInfo
	mi.CbSize = uint32(unsafe.Sizeof(mi))
	if mon != 0 {
		if r, _, _ := pGetMonitorInfoW.Call(mon, uintptr(unsafe.Pointer(&mi))); r != 0 {
			return mi.RcWork, mi.RcMonitor
		}
	}
	sw, sh := screenSize()
	fr := winRect{0, 0, int32(sw), int32(sh)}
	return fr, fr
}

func focusExisting() bool {
	title, _ := syscall.UTF16PtrFromString("VozduhLaucher")
	hwnd, _, _ := pFindWindowW.Call(0, uintptr(unsafe.Pointer(title)))
	if hwnd == 0 {
		return false
	}
	pShowWindow.Call(hwnd, swRestore)
	pSetForegroundWnd.Call(hwnd)
	return true
}

// window state shared with JS bindings
type winCtl struct {
	hwnd       uintptr
	mode       string // "", "max", "full"
	normalRect winRect
}

func (c *winCtl) enter(target winRect, mode string) {
	if c.mode == "" {
		pGetWindowRect.Call(c.hwnd, uintptr(unsafe.Pointer(&c.normalRect)))
	}
	c.mode = mode
	r := target
	pSetWindowPos.Call(c.hwnd, 0, uintptr(uint32(r.Left)), uintptr(uint32(r.Top)),
		uintptr(uint32(r.Right-r.Left)), uintptr(uint32(r.Bottom-r.Top)), swpFrameChanged|swpNoZOrder|swpShow)
}

func (c *winCtl) restore() {
	c.mode = ""
	r := c.normalRect
	if r.Right-r.Left < 200 {
		return
	}
	pSetWindowPos.Call(c.hwnd, 0, uintptr(uint32(r.Left)), uintptr(uint32(r.Top)),
		uintptr(uint32(r.Right-r.Left)), uintptr(uint32(r.Bottom-r.Top)), swpFrameChanged|swpNoZOrder|swpShow)
}

func (c *winCtl) maximizeToggle() bool {
	if c.mode == "max" {
		c.restore()
		return false
	}
	work, _ := monitorWork(c.hwnd)
	c.enter(work, "max")
	return true
}

func (c *winCtl) fullscreenToggle() bool {
	if c.mode == "full" {
		c.restore()
		return false
	}
	_, full := monitorWork(c.hwnd)
	c.enter(full, "full")
	return true
}

func (c *winCtl) minimize() { pShowWindow.Call(c.hwnd, swMinimize) }
func (c *winCtl) close()    { pPostMessageW.Call(c.hwnd, wmClose, 0, 0) }

func (c *winCtl) dragMove() {
	if c.mode == "max" || c.mode == "full" {
		c.restore()
	}
	pReleaseCapture.Call()
	pSendMessageW.Call(c.hwnd, wmNCLButtonDown, htCaption, 0)
}

func (c *winCtl) resize(dir string) {
	if c.mode == "max" || c.mode == "full" {
		return
	}
	ht, ok := htCodes[dir]
	if !ok {
		return
	}
	pReleaseCapture.Call()
	pSendMessageW.Call(c.hwnd, wmNCLButtonDown, ht, 0)
}

// makeFrameless strips the system title bar (keeping WS_THICKFRAME for resize)
// and subclasses the window so the WebView2 fills it edge-to-edge.
func makeFrameless(hwnd uintptr) {
	style := uintptr(wsPopup | wsThickFrame | wsMinimizeBox | wsMaximizeBox | wsSysMenu | wsClipChild | wsClipSib | wsVisible)
	pSetWindowLongW.Call(hwnd, gwlStyle, style)

	// subclass to drop the non-client frame (full-bleed content)
	origWndProc, _, _ = pGetWindowLongPtrW.Call(hwnd, gwlpWndProc)
	cb := syscall.NewCallback(wndProc)
	pSetWindowLongPtrW.Call(hwnd, gwlpWndProc, cb)

	sw, sh := screenSize()
	w := sw * 86 / 100
	h := sh * 86 / 100
	x := (sw - w) / 2
	y := (sh - h) / 2
	pSetWindowPos.Call(hwnd, 0, uintptr(uint32(int32(x))), uintptr(uint32(int32(y))),
		uintptr(w), uintptr(h), swpFrameChanged|swpNoZOrder|swpShow)
}

// runUINative opens the launcher in a real native window with embedded WebView2.
// Blocks until the window is closed. Returns false if WebView2 is unavailable.
func runUINative(url string) bool {
	ok := true
	defer func() {
		if recover() != nil {
			ok = false
		}
	}()
	sw, sh := screenSize()
	w := sw * 86 / 100
	h := sh * 86 / 100

	wv := webview2.NewWithOptions(webview2.WebViewOptions{
		Debug:     false,
		AutoFocus: true,
		DataPath:  filepath.Join(launcherRoot(), "uiprofile"),
		WindowOptions: webview2.WindowOptions{
			Title:  "VozduhLaucher",
			Width:  uint(w),
			Height: uint(h),
			IconId: 1,
			Center: true,
		},
	})
	if wv == nil {
		return false
	}
	defer wv.Destroy()
	wv.SetSize(920, 640, webview2.HintMin)

	hwnd := uintptr(wv.Window())
	ctl := &winCtl{hwnd: hwnd}
	makeFrameless(hwnd)

	// Bind callbacks already run on the UI (message-loop) thread, so the Win32
	// calls must be made directly here. Dispatching + waiting would deadlock.
	wv.Bind("winMinimize", func() { ctl.minimize() })
	wv.Bind("winClose", func() { ctl.close() })
	wv.Bind("winMaximizeToggle", func() bool { return ctl.maximizeToggle() })
	wv.Bind("winFullscreenToggle", func() bool { return ctl.fullscreenToggle() })
	wv.Bind("winIsMaximized", func() bool { return ctl.mode == "max" || ctl.mode == "full" })
	wv.Bind("winDrag", func() { ctl.dragMove() })
	wv.Bind("winResize", func(dir string) { ctl.resize(dir) })

	wv.Navigate(url)
	wv.Run()
	return ok
}

// ---------- fallback: Edge/Chrome app-mode window (if WebView2 is missing) ----------

func findBrowser() (string, bool) {
	candidates := []string{
		filepath.Join(os.Getenv("ProgramFiles(x86)"), `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(os.Getenv("ProgramFiles"), `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(os.Getenv("LOCALAPPDATA"), `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(os.Getenv("ProgramFiles"), `Google\Chrome\Application\chrome.exe`),
		filepath.Join(os.Getenv("ProgramFiles(x86)"), `Google\Chrome\Application\chrome.exe`),
		filepath.Join(os.Getenv("LOCALAPPDATA"), `Google\Chrome\Application\chrome.exe`),
	}
	for _, c := range candidates {
		if _, err := os.Stat(c); err == nil {
			return c, true
		}
	}
	return "", false
}

func openWindow(url string) {
	sw, sh := screenSize()
	w := sw * 86 / 100
	h := sh * 86 / 100
	x := (sw - w) / 2
	y := (sh - h) / 2
	if browser, ok := findBrowser(); ok {
		profile := filepath.Join(launcherRoot(), "uiprofile-b")
		args := []string{
			"--app=" + url,
			fmt.Sprintf("--window-size=%d,%d", w, h),
			fmt.Sprintf("--window-position=%d,%d", x, y),
			"--user-data-dir=" + profile,
			"--no-first-run",
			"--no-default-browser-check",
		}
		exec.Command(browser, args...).Start()
		return
	}
	exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
}

var _ = kernel
