#!/usr/bin/env python3
"""Set a valid Authenticode-style PE checksum in the optional header.
Go leaves this field at 0; a zero checksum is a mild 'suspicious' signal for
some AV/ML heuristics. Setting the real checksum makes the PE look like a
normally-built executable. No effect on behaviour."""
import sys, struct

def pe_checksum(data, off):
    b = bytearray(data)
    b[off:off+4] = b"\x00\x00\x00\x00"
    total = 0
    n = len(b)
    for i in range(0, n - (n & 1), 2):
        total += b[i] | (b[i+1] << 8)
        total = (total & 0xffff) + (total >> 16)
    if n & 1:
        total += b[-1]
        total = (total & 0xffff) + (total >> 16)
    total = (total & 0xffff) + (total >> 16)
    total = (total + (total >> 16)) & 0xffff
    return (total + n) & 0xffffffff

def main(path):
    data = bytearray(open(path, "rb").read())
    if data[:2] != b"MZ":
        raise SystemExit("not a PE file")
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    if data[e_lfanew:e_lfanew+4] != b"PE\x00\x00":
        raise SystemExit("bad PE signature")
    csum_off = e_lfanew + 24 + 64  # optional header start + CheckSum field offset
    val = pe_checksum(data, csum_off)
    struct.pack_into("<I", data, csum_off, val)
    open(path, "wb").write(data)
    print(f"PE checksum set to 0x{val:08x} for {path}")

if __name__ == "__main__":
    main(sys.argv[1])
