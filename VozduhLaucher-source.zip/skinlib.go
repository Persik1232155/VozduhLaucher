package main

import (
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// TL Skins & Cape library: a GitHub repo with one skin mod per Minecraft
// version (or per version range), split into Fabric/ and Forge/ folders.
// The launcher downloads ONLY the single jar for the requested version, not the
// whole repo. Folder names look like "fabric 1.21.4" or "fabric 1.21.6-1.21.8"
// (a dash means the mod covers that inclusive range of versions).

const skinRepo = "Persik1232155/Tl_skins-lib-"
const skinBranch = "main"

type skinEntry struct {
	loader string // fabric | forge
	spec   string // version spec after the loader prefix, e.g. "1.21.4" or "1.21.6-1.21.8"
	path   string // full blob path of the jar inside the repo
}

var skinLibCache struct {
	sync.Mutex
	entries []skinEntry
	at      time.Time
}

type ghTree struct {
	Tree []struct {
		Path string `json:"path"`
		Type string `json:"type"`
	} `json:"tree"`
	Truncated bool `json:"truncated"`
}

func loadSkinLib() ([]skinEntry, error) {
	skinLibCache.Lock()
	defer skinLibCache.Unlock()
	if skinLibCache.entries != nil && time.Since(skinLibCache.at) < 30*time.Minute {
		return skinLibCache.entries, nil
	}
	var t ghTree
	if err := fetchJSON("https://api.github.com/repos/"+skinRepo+"/git/trees/"+skinBranch+"?recursive=1", &t); err != nil {
		return nil, err
	}
	var out []skinEntry
	for _, e := range t.Tree {
		if e.Type != "blob" || !strings.HasSuffix(strings.ToLower(e.Path), ".jar") {
			continue
		}
		segs := strings.Split(e.Path, "/")
		li, loader := -1, ""
		for i, s := range segs {
			ls := strings.ToLower(s)
			if ls == "fabric" || ls == "forge" {
				li, loader = i, ls
				break
			}
		}
		if li < 0 || li+1 >= len(segs) {
			continue
		}
		spec := strings.TrimSpace(segs[li+1])
		if low := strings.ToLower(spec); strings.HasPrefix(low, loader+" ") {
			spec = strings.TrimSpace(spec[len(loader)+1:])
		}
		out = append(out, skinEntry{loader: loader, spec: spec, path: e.Path})
	}
	skinLibCache.entries = out
	skinLibCache.at = time.Now()
	return out, nil
}

// verTuple parses "1.21.4" -> [1 21 4], tolerating junk like "1.20." -> [1 20].
func verTuple(s string) []int {
	var out []int
	for _, part := range strings.Split(strings.TrimSpace(s), ".") {
		digits := ""
		for _, c := range part {
			if c >= '0' && c <= '9' {
				digits += string(c)
			}
		}
		if digits == "" {
			continue
		}
		n := 0
		fmt.Sscanf(digits, "%d", &n)
		out = append(out, n)
	}
	return out
}

func cmpTuple(a, b []int) int {
	for i := 0; i < len(a) && i < len(b); i++ {
		if a[i] != b[i] {
			if a[i] < b[i] {
				return -1
			}
			return 1
		}
	}
	switch {
	case len(a) < len(b):
		return -1
	case len(a) > len(b):
		return 1
	}
	return 0
}

// specMatch reports whether mc is covered by a folder version spec. A spec with
// a dash is an inclusive range (1.21.6-1.21.8 covers 1.21.6, 1.21.7, 1.21.8).
func specMatch(spec, mc string) bool {
	m := verTuple(mc)
	if len(m) == 0 {
		return false
	}
	if strings.Contains(spec, "-") {
		parts := strings.SplitN(spec, "-", 2)
		lo, hi := verTuple(parts[0]), verTuple(parts[1])
		if len(lo) == 0 || len(hi) == 0 {
			return false
		}
		return cmpTuple(lo, m) <= 0 && cmpTuple(m, hi) <= 0
	}
	return cmpTuple(verTuple(spec), m) == 0
}

func skinLibFind(loader, mc string) (string, bool) {
	if loader != "fabric" && loader != "forge" {
		return "", false
	}
	entries, err := loadSkinLib()
	if err != nil {
		return "", false
	}
	for _, e := range entries {
		if e.loader == loader && specMatch(e.spec, mc) {
			return e.path, true
		}
	}
	return "", false
}

func skinLibSupported(loader, mc string) bool {
	_, ok := skinLibFind(loader, mc)
	return ok
}

// rawGitHubURL builds a raw.githubusercontent.com URL with each path segment
// URL-encoded (spaces -> %20).
func rawGitHubURL(repo, branch, path string) string {
	segs := strings.Split(path, "/")
	for i, s := range segs {
		segs[i] = url.PathEscape(s)
	}
	return "https://raw.githubusercontent.com/" + repo + "/" + branch + "/" + strings.Join(segs, "/")
}

// skinInstalledJars returns the TL Skin & Cape jar file names present in mods/.
func skinInstalledJars(v *Version) []string {
	var out []string
	entries, _ := os.ReadDir(filepath.Join(instanceDir(v), "mods"))
	for _, e := range entries {
		low := strings.ToLower(e.Name())
		if !strings.HasSuffix(low, ".jar") {
			continue
		}
		if strings.Contains(low, "skin-and-cape") || strings.Contains(low, "tl-skin") {
			out = append(out, e.Name())
		}
	}
	return out
}

func isSkinInstalled(v *Version) bool { return len(skinInstalledJars(v)) > 0 }

func removeSkinLib(vid string) error {
	v := versionSnapshot(vid)
	if v == nil {
		return fmt.Errorf("not found")
	}
	modsDir := filepath.Join(instanceDir(v), "mods")
	for _, name := range skinInstalledJars(v) {
		os.Remove(filepath.Join(modsDir, name))
	}
	return nil
}

func installSkinLib(vid string) {
	v := versionSnapshot(vid)
	if v == nil {
		return
	}
	path, ok := skinLibFind(v.Loader, v.MC)
	if !ok {
		reportState(vid, "error", "на эту версию нету скинов")
		return
	}
	reportState(vid, "installing", "")
	err := func() error {
		modsDir := filepath.Join(instanceDir(v), "mods")
		os.MkdirAll(modsDir, 0o755)
		reportProgress(vid, "skins", 0, 0, "download")
		dst := filepath.Join(modsDir, filepath.Base(path))
		if err := downloadFile(rawGitHubURL(skinRepo, skinBranch, path), dst, ""); err != nil {
			return err
		}
		if v.Loader == "fabric" && !hasFabricAPI(modsDir) {
			reportProgress(vid, "skins", 0, 0, "fabric-api")
			mrInstall(v, "fabric-api", "mod") // best-effort dependency
		}
		return nil
	}()
	if err != nil {
		reportState(vid, "error", "Скины: "+err.Error())
		return
	}
	reportState(vid, "ready", "")
	pushStateAll()
}
