package main

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// ---------- Mojang manifest ----------

type mojangManifest struct {
	Latest struct {
		Release  string `json:"release"`
		Snapshot string `json:"snapshot"`
	} `json:"latest"`
	Versions []struct {
		ID          string `json:"id"`
		Type        string `json:"type"`
		URL         string `json:"url"`
		SHA1        string `json:"sha1"`
		ReleaseTime string `json:"releaseTime"`
	} `json:"versions"`
}

var (
	manifestMu     sync.Mutex
	cachedManifest *mojangManifest
	manifestTime   time.Time
)

func getManifest() (*mojangManifest, error) {
	manifestMu.Lock()
	defer manifestMu.Unlock()
	if cachedManifest != nil && time.Since(manifestTime) < 10*time.Minute {
		return cachedManifest, nil
	}
	var m mojangManifest
	err := fetchJSON("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json", &m)
	cachePath := filepath.Join(cacheDir(), "version_manifest.json")
	if err != nil {
		// offline fallback to cached copy
		if b, e := os.ReadFile(cachePath); e == nil && json.Unmarshal(b, &m) == nil {
			cachedManifest = &m
			manifestTime = time.Now()
			return &m, nil
		}
		return nil, err
	}
	os.MkdirAll(cacheDir(), 0o755)
	if b, e := json.Marshal(&m); e == nil {
		os.WriteFile(cachePath, b, 0o644)
	}
	cachedManifest = &m
	manifestTime = time.Now()
	return &m, nil
}

func manifestEntry(mc string) (url, sha string, err error) {
	m, err := getManifest()
	if err != nil {
		return "", "", err
	}
	for _, v := range m.Versions {
		if v.ID == mc {
			return v.URL, v.SHA1, nil
		}
	}
	return "", "", fmt.Errorf("version %s not found", mc)
}

// ---------- installable version lists per loader ----------

type mcVersionInfo struct {
	ID      string `json:"id"`
	Type    string `json:"type"` // release | snapshot | old_beta | old_alpha
	Release string `json:"release"`
}

var loaderListCache sync.Map // loader -> []mcVersionInfo (+time)

type loaderListEntry struct {
	list []mcVersionInfo
	at   time.Time
}

func listVersionsForLoader(loader string) ([]mcVersionInfo, error) {
	if e, ok := loaderListCache.Load(loader); ok {
		le := e.(loaderListEntry)
		if time.Since(le.at) < 10*time.Minute {
			return le.list, nil
		}
	}
	list, err := fetchVersionsForLoader(loader)
	if err != nil {
		return nil, err
	}
	loaderListCache.Store(loader, loaderListEntry{list, time.Now()})
	return list, nil
}

func fetchVersionsForLoader(loader string) ([]mcVersionInfo, error) {
	m, err := getManifest()
	if err != nil && loader != "forge" && loader != "neoforge" && loader != "liteloader" {
		return nil, err
	}
	byID := map[string]mcVersionInfo{}
	var all []mcVersionInfo
	if m != nil {
		for _, v := range m.Versions {
			info := mcVersionInfo{ID: v.ID, Type: v.Type, Release: v.ReleaseTime}
			byID[v.ID] = info
			all = append(all, info)
		}
	}
	switch loader {
	case "vanilla":
		return all, nil
	case "fabric":
		var games []struct {
			Version string `json:"version"`
			Stable  bool   `json:"stable"`
		}
		if err := fetchJSON("https://meta.fabricmc.net/v2/versions/game", &games); err != nil {
			return nil, err
		}
		var out []mcVersionInfo
		for _, g := range games {
			if info, ok := byID[g.Version]; ok {
				out = append(out, info)
			} else {
				t := "snapshot"
				if g.Stable {
					t = "release"
				}
				out = append(out, mcVersionInfo{ID: g.Version, Type: t})
			}
		}
		return out, nil
	case "quilt":
		var games []struct {
			Version string `json:"version"`
			Stable  bool   `json:"stable"`
		}
		if err := fetchJSON("https://meta.quiltmc.org/v3/versions/game", &games); err != nil {
			return nil, err
		}
		var out []mcVersionInfo
		for _, g := range games {
			if info, ok := byID[g.Version]; ok {
				out = append(out, info)
			} else {
				t := "snapshot"
				if g.Stable {
					t = "release"
				}
				out = append(out, mcVersionInfo{ID: g.Version, Type: t})
			}
		}
		return out, nil
	case "forge":
		mcs, err := forgeSupportedMCs()
		if err != nil {
			return nil, err
		}
		return sortedByManifest(mcs, byID, all), nil
	case "neoforge":
		mcs, err := neoforgeSupportedMCs()
		if err != nil {
			return nil, err
		}
		return sortedByManifest(mcs, byID, all), nil
	case "liteloader":
		mcs, err := liteloaderSupportedMCs()
		if err != nil {
			return nil, err
		}
		return sortedByManifest(mcs, byID, all), nil
	}
	return nil, fmt.Errorf("unknown loader %s", loader)
}

// keep manifest (newest-first) ordering for a set of mc ids
func sortedByManifest(mcs []string, byID map[string]mcVersionInfo, all []mcVersionInfo) []mcVersionInfo {
	set := map[string]bool{}
	for _, id := range mcs {
		set[id] = true
	}
	var out []mcVersionInfo
	for _, v := range all {
		if set[v.ID] {
			out = append(out, v)
			delete(set, v.ID)
		}
	}
	// leftovers unknown to manifest, natural order
	var rest []string
	for id := range set {
		rest = append(rest, id)
	}
	sort.Sort(sort.Reverse(sort.StringSlice(rest)))
	for _, id := range rest {
		out = append(out, mcVersionInfo{ID: id, Type: "release"})
	}
	return out
}

// ---------- Forge ----------

type mavenMetadata struct {
	Versioning struct {
		Versions struct {
			Version []string `xml:"version"`
		} `xml:"versions"`
	} `xml:"versioning"`
}

var forgeVersionsCache struct {
	sync.Mutex
	byMC map[string][]string // mc -> forge versions (e.g. "1.21.1-52.0.9"), newest last
	at   time.Time
}

func forgeAll() (map[string][]string, error) {
	forgeVersionsCache.Lock()
	defer forgeVersionsCache.Unlock()
	if forgeVersionsCache.byMC != nil && time.Since(forgeVersionsCache.at) < 10*time.Minute {
		return forgeVersionsCache.byMC, nil
	}
	b, err := fetchBytes("https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml")
	if err != nil {
		return nil, err
	}
	var md mavenMetadata
	if err := xml.Unmarshal(b, &md); err != nil {
		return nil, err
	}
	byMC := map[string][]string{}
	for _, v := range md.Versioning.Versions.Version {
		parts := strings.SplitN(v, "-", 2)
		if len(parts) != 2 {
			continue
		}
		mc := parts[0]
		byMC[mc] = append(byMC[mc], v)
	}
	forgeVersionsCache.byMC = byMC
	forgeVersionsCache.at = time.Now()
	return byMC, nil
}

func forgeSupportedMCs() ([]string, error) {
	byMC, err := forgeAll()
	if err != nil {
		return nil, err
	}
	var out []string
	for mc := range byMC {
		out = append(out, mc)
	}
	return out, nil
}

// latest (recommended if available) forge build for mc
func forgeLatestFor(mc string) (string, error) {
	// try promotions for recommended
	var promos struct {
		Promos map[string]string `json:"promos"`
	}
	if err := fetchJSON("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json", &promos); err == nil {
		if v, ok := promos.Promos[mc+"-recommended"]; ok && v != "" {
			return mc + "-" + v, nil
		}
		if v, ok := promos.Promos[mc+"-latest"]; ok && v != "" {
			return mc + "-" + v, nil
		}
	}
	byMC, err := forgeAll()
	if err != nil {
		return "", err
	}
	list := byMC[mc]
	if len(list) == 0 {
		return "", fmt.Errorf("Forge not available for %s", mc)
	}
	return list[len(list)-1], nil
}

// ---------- NeoForge ----------

var neoCache struct {
	sync.Mutex
	versions []string
	at       time.Time
}

func neoAll() ([]string, error) {
	neoCache.Lock()
	defer neoCache.Unlock()
	if neoCache.versions != nil && time.Since(neoCache.at) < 10*time.Minute {
		return neoCache.versions, nil
	}
	b, err := fetchBytes("https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml")
	if err != nil {
		return nil, err
	}
	var md mavenMetadata
	if err := xml.Unmarshal(b, &md); err != nil {
		return nil, err
	}
	neoCache.versions = md.Versioning.Versions.Version
	neoCache.at = time.Now()
	return neoCache.versions, nil
}

// neoforge version "21.1.77" -> mc "1.21.1"; "20.4.x" -> 1.20.4; "26.2.x" -> 1.26.2 style
func neoMCFor(nfv string) string {
	parts := strings.Split(nfv, ".")
	if len(parts) < 2 {
		return ""
	}
	if parts[1] == "0" {
		return "1." + parts[0]
	}
	return "1." + parts[0] + "." + parts[1]
}

func neoforgeSupportedMCs() ([]string, error) {
	vs, err := neoAll()
	if err != nil {
		return nil, err
	}
	seen := map[string]bool{}
	var out []string
	for _, v := range vs {
		mc := neoMCFor(v)
		if mc != "" && !seen[mc] {
			seen[mc] = true
			out = append(out, mc)
		}
	}
	return out, nil
}

func neoforgeLatestFor(mc string) (string, error) {
	vs, err := neoAll()
	if err != nil {
		return "", err
	}
	var best string
	for _, v := range vs {
		if neoMCFor(v) == mc && !strings.Contains(v, "beta") {
			best = v
		}
	}
	if best == "" { // allow betas if that's all there is
		for _, v := range vs {
			if neoMCFor(v) == mc {
				best = v
			}
		}
	}
	if best == "" {
		return "", fmt.Errorf("NeoForge not available for %s", mc)
	}
	return best, nil
}

// ---------- LiteLoader ----------

type liteloaderMeta struct {
	Versions map[string]struct {
		Artefacts map[string]map[string]struct {
			TweakClass string `json:"tweakClass"`
			File       string `json:"file"`
			Version    string `json:"version"`
			MD5        string `json:"md5"`
		} `json:"artefacts"`
		Repo struct {
			URL string `json:"url"`
		} `json:"repo"`
	} `json:"versions"`
}

var llCache struct {
	sync.Mutex
	meta *liteloaderMeta
	at   time.Time
}

func liteloaderAll() (*liteloaderMeta, error) {
	llCache.Lock()
	defer llCache.Unlock()
	if llCache.meta != nil && time.Since(llCache.at) < 30*time.Minute {
		return llCache.meta, nil
	}
	var m liteloaderMeta
	if err := fetchJSON("https://dl.liteloader.com/versions/versions.json", &m); err != nil {
		if err2 := fetchJSON("http://dl.liteloader.com/versions/versions.json", &m); err2 != nil {
			return nil, err
		}
	}
	llCache.meta = &m
	llCache.at = time.Now()
	return &m, nil
}

func liteloaderSupportedMCs() ([]string, error) {
	m, err := liteloaderAll()
	if err != nil {
		return nil, err
	}
	var out []string
	for mc, v := range m.Versions {
		if v.Artefacts != nil {
			out = append(out, mc)
		}
	}
	return out, nil
}
