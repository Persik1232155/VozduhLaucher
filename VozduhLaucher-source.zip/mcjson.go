package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------- Minecraft version JSON ----------

type vjRule struct {
	Action string `json:"action"`
	OS     *struct {
		Name string `json:"name"`
		Arch string `json:"arch"`
	} `json:"os,omitempty"`
	Features map[string]bool `json:"features,omitempty"`
}

type vjArtifact struct {
	Path string `json:"path"`
	SHA1 string `json:"sha1"`
	Size int64  `json:"size"`
	URL  string `json:"url"`
}

type vjLibrary struct {
	Name      string `json:"name"`
	URL       string `json:"url,omitempty"` // maven base (fabric style)
	Downloads *struct {
		Artifact    *vjArtifact            `json:"artifact,omitempty"`
		Classifiers map[string]*vjArtifact `json:"classifiers,omitempty"`
	} `json:"downloads,omitempty"`
	Natives map[string]string `json:"natives,omitempty"`
	Rules   []vjRule          `json:"rules,omitempty"`
	Extract *struct {
		Exclude []string `json:"exclude"`
	} `json:"extract,omitempty"`
}

type vjArgValue struct {
	Plain string
	List  []string
	Rules []vjRule
}

func (a *vjArgValue) UnmarshalJSON(b []byte) error {
	var s string
	if json.Unmarshal(b, &s) == nil {
		a.Plain = s
		return nil
	}
	var obj struct {
		Rules []vjRule        `json:"rules"`
		Value json.RawMessage `json:"value"`
	}
	if err := json.Unmarshal(b, &obj); err != nil {
		return err
	}
	a.Rules = obj.Rules
	var vs string
	if json.Unmarshal(obj.Value, &vs) == nil {
		a.List = []string{vs}
		return nil
	}
	return json.Unmarshal(obj.Value, &a.List)
}

type versionJSON struct {
	ID           string `json:"id"`
	InheritsFrom string `json:"inheritsFrom,omitempty"`
	Type         string `json:"type"`
	MainClass    string `json:"mainClass"`
	Assets       string `json:"assets"`
	AssetIndex   *struct {
		ID   string `json:"id"`
		SHA1 string `json:"sha1"`
		Size int64  `json:"size"`
		URL  string `json:"url"`
	} `json:"assetIndex,omitempty"`
	Downloads map[string]*vjArtifact `json:"downloads,omitempty"`
	Libraries []vjLibrary            `json:"libraries"`
	Arguments *struct {
		Game []vjArgValue `json:"game"`
		JVM  []vjArgValue `json:"jvm"`
	} `json:"arguments,omitempty"`
	MinecraftArguments string `json:"minecraftArguments,omitempty"`
	JavaVersion        *struct {
		Component    string `json:"component"`
		MajorVersion int    `json:"majorVersion"`
	} `json:"javaVersion,omitempty"`
	Logging map[string]struct {
		Argument string `json:"argument"`
		File     struct {
			ID   string `json:"id"`
			SHA1 string `json:"sha1"`
			URL  string `json:"url"`
		} `json:"file"`
	} `json:"logging,omitempty"`
}

func readVersionJSON(id string) (*versionJSON, error) {
	p := filepath.Join(versionsDir(), id, id+".json")
	b, err := os.ReadFile(p)
	if err != nil {
		return nil, err
	}
	var v versionJSON
	if err := json.Unmarshal(b, &v); err != nil {
		return nil, err
	}
	return &v, nil
}

// resolveVersion merges the inheritsFrom chain into one effective JSON.
// Child values win; libraries are child-first + parent.
func resolveVersion(id string) (*versionJSON, error) {
	var chain []*versionJSON
	cur := id
	for i := 0; i < 8 && cur != ""; i++ {
		v, err := readVersionJSON(cur)
		if err != nil {
			return nil, err
		}
		chain = append(chain, v)
		cur = v.InheritsFrom
	}
	eff := &versionJSON{}
	// walk from root parent to child
	for i := len(chain) - 1; i >= 0; i-- {
		v := chain[i]
		if v.MainClass != "" {
			eff.MainClass = v.MainClass
		}
		if v.Assets != "" {
			eff.Assets = v.Assets
		}
		if v.AssetIndex != nil {
			eff.AssetIndex = v.AssetIndex
		}
		if v.Downloads != nil {
			if eff.Downloads == nil {
				eff.Downloads = map[string]*vjArtifact{}
			}
			for k, a := range v.Downloads {
				eff.Downloads[k] = a
			}
		}
		if v.JavaVersion != nil {
			eff.JavaVersion = v.JavaVersion
		}
		if v.Logging != nil {
			eff.Logging = v.Logging
		}
		if v.MinecraftArguments != "" {
			eff.MinecraftArguments = v.MinecraftArguments
		}
		if v.Arguments != nil {
			if eff.Arguments == nil {
				eff.Arguments = &struct {
					Game []vjArgValue `json:"game"`
					JVM  []vjArgValue `json:"jvm"`
				}{}
			}
			eff.Arguments.Game = append(eff.Arguments.Game, v.Arguments.Game...)
			eff.Arguments.JVM = append(eff.Arguments.JVM, v.Arguments.JVM...)
		}
		if v.Type != "" {
			eff.Type = v.Type
		}
		eff.ID = chain[0].ID
	}
	// libraries child-first so loader libs win dedupe and precede vanilla on classpath
	for i := 0; i < len(chain); i++ {
		eff.Libraries = append(eff.Libraries, chain[i].Libraries...)
	}
	return eff, nil
}

// libKey returns "group:artifact[:classifier]" (dedupe key ignoring version).
func libKey(name string) string {
	if i := strings.Index(name, "@"); i >= 0 {
		name = name[:i]
	}
	parts := strings.Split(name, ":")
	if len(parts) < 2 {
		return name
	}
	key := parts[0] + ":" + parts[1]
	if len(parts) >= 4 { // classifier present (e.g. natives-windows)
		key += ":" + parts[3]
	}
	return key
}

func rulesAllow(rules []vjRule, features map[string]bool) bool {
	if len(rules) == 0 {
		return true
	}
	allowed := false
	for _, r := range rules {
		match := true
		if r.OS != nil {
			if r.OS.Name != "" && r.OS.Name != "windows" {
				match = false
			}
			if r.OS.Arch != "" && r.OS.Arch != "x86_64" && r.OS.Arch != "x64" {
				// we target x64 windows
				if r.OS.Arch == "x86" {
					match = false
				}
			}
		}
		if r.Features != nil {
			for k, want := range r.Features {
				if features == nil || features[k] != want {
					match = false
				}
			}
		}
		if match {
			allowed = r.Action == "allow"
		}
	}
	return allowed
}

// mavenPath converts "group:artifact:version[:classifier][@ext]" to repo path.
func mavenPath(name string) string {
	ext := "jar"
	if i := strings.Index(name, "@"); i >= 0 {
		ext = name[i+1:]
		name = name[:i]
	}
	parts := strings.Split(name, ":")
	if len(parts) < 3 {
		return ""
	}
	group := strings.ReplaceAll(parts[0], ".", "/")
	artifact := parts[1]
	ver := parts[2]
	classifier := ""
	if len(parts) >= 4 {
		classifier = "-" + parts[3]
	}
	return fmt.Sprintf("%s/%s/%s/%s-%s%s.%s", group, artifact, ver, artifact, ver, classifier, ext)
}

// libraryJobs returns download jobs + classpath entries + natives entries for windows x64.
func libraryJobs(eff *versionJSON) (jobs []dlJob, classpath []string, natives []nativeEntry) {
	seen := map[string]bool{}
	for _, lib := range eff.Libraries {
		if !rulesAllow(lib.Rules, nil) {
			continue
		}
		// modern artifact
		if lib.Downloads != nil && lib.Downloads.Artifact != nil && lib.Downloads.Artifact.Path != "" {
			a := lib.Downloads.Artifact
			p := filepath.Join(librariesDir(), filepath.FromSlash(a.Path))
			key := a.Path
			if lib.Name != "" {
				key = libKey(lib.Name)
			}
			if !seen[key] {
				seen[key] = true
				if a.URL != "" {
					jobs = append(jobs, dlJob{URL: a.URL, Path: p, SHA: a.SHA1, Size: a.Size})
				}
				classpath = append(classpath, p)
			}
		} else if lib.Name != "" && (lib.Downloads == nil || lib.Downloads.Artifact == nil) && lib.Natives == nil {
			// fabric/maven style
			mp := mavenPath(lib.Name)
			if mp != "" {
				base := lib.URL
				if base == "" {
					base = "https://libraries.minecraft.net/"
				}
				if !strings.HasSuffix(base, "/") {
					base += "/"
				}
				p := filepath.Join(librariesDir(), filepath.FromSlash(mp))
				key := libKey(lib.Name)
				if !seen[key] {
					seen[key] = true
					jobs = append(jobs, dlJob{URL: base + mp, Path: p})
					classpath = append(classpath, p)
				}
			}
		}
		// legacy natives
		if lib.Natives != nil {
			cls, ok := lib.Natives["windows"]
			if !ok {
				continue
			}
			cls = strings.ReplaceAll(cls, "${arch}", "64")
			if lib.Downloads != nil && lib.Downloads.Classifiers != nil {
				if a := lib.Downloads.Classifiers[cls]; a != nil {
					p := filepath.Join(librariesDir(), filepath.FromSlash(a.Path))
					if !seen[a.Path] {
						seen[a.Path] = true
						jobs = append(jobs, dlJob{URL: a.URL, Path: p, SHA: a.SHA1, Size: a.Size})
					}
					var excl []string
					if lib.Extract != nil {
						excl = lib.Extract.Exclude
					}
					natives = append(natives, nativeEntry{Path: p, Exclude: excl})
				}
			}
		}
	}
	return
}

type nativeEntry struct {
	Path    string
	Exclude []string
}
