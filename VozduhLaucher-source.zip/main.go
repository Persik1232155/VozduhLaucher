package main

import (
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"runtime"
)

const preferredPort = 42737

func init() {
	// the native UI message loop must run on the main OS thread
	runtime.LockOSThread()
}

func main() {
	dev := flag.Bool("dev", false, "dev mode: no window, no exit watchdog")
	root := flag.String("root", "", "override data root dir")
	flag.Parse()
	if *root != "" {
		rootDir = *root
	}

	makeDPIAware()
	loadConfig()
	os.MkdirAll(launcherRoot(), 0o755)

	// single instance: if a VozduhLaucher is already running, focus its window
	addr := fmt.Sprintf("127.0.0.1:%d", preferredPort)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		url := "http://" + addr
		resp, e := http.Get(url + "/api/ident")
		if e == nil {
			resp.Body.Close()
			if !*dev {
				if !focusExisting() {
					// window was closed but server alive: open a fresh one
					if !runUINative(url) {
						openWindow(url)
					}
				}
			}
			return
		}
		// port taken by something else: pick a free one
		ln, err = net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}

	url := fmt.Sprintf("http://%s", ln.Addr().String())
	mux := buildMux()
	go http.Serve(ln, mux)

	if *dev {
		fmt.Println("UI at:", url)
		go watchdog(true)
		select {}
	}

	if runUINative(url) {
		// window closed by the user; running games keep running on their own
		os.Exit(0)
	}

	// WebView2 unavailable: browser app-window fallback with idle watchdog
	go watchdog(false)
	openWindow(url)
	select {}
}
