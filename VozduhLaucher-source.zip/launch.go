package main

import (
	"crypto/md5"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------- run states ----------

var (
	runMu     sync.Mutex
	runStates = map[string]string{} // vid -> installing|launching|running|error|""
	runProcs  = map[string]*exec.Cmd{}
)

func setRunState(vid, s string) {
	runMu.Lock()
	if s == "" || s == "ready" {
		delete(runStates, vid)
	} else {
		runStates[vid] = s
	}
	runMu.Unlock()
}

func getRunStates() map[string]string {
	runMu.Lock()
	defer runMu.Unlock()
	out := map[string]string{}
	for k, v := range runStates {
		out[k] = v
	}
	return out
}

func anyGameRunning() bool {
	runMu.Lock()
	defer runMu.Unlock()
	for _, v := range runStates {
		if v == "running" || v == "launching" || v == "installing" {
			return true
		}
	}
	return false
}

// offlineUUID matches vanilla offline mode: UUIDv3 of "OfflinePlayer:<name>"
func offlineUUID(name string) string {
	h := md5.Sum([]byte("OfflinePlayer:" + name))
	h[6] = (h[6] & 0x0f) | 0x30
	h[8] = (h[8] & 0x3f) | 0x80
	hexs := fmt.Sprintf("%x", h)
	return fmt.Sprintf("%s-%s-%s-%s-%s", hexs[0:8], hexs[8:12], hexs[12:16], hexs[16:20], hexs[20:32])
}

func substituteVars(s string, vars map[string]string) string {
	for k, v := range vars {
		s = strings.ReplaceAll(s, "${"+k+"}", v)
	}
	return s
}

func doLaunch(vid string) {
	v := versionSnapshot(vid)
	if v == nil {
		return
	}
	if v.VersionID == "" {
		reportState(vid, "error", "not installed")
		return
	}
	// record last played
	cfgMu.Lock()
	if _, _, vv := findVersionLocked(vid); vv != nil {
		vv.LastPlayed = time.Now().Unix()
		saveConfigLocked()
	}
	cfgMu.Unlock()
	pushStateAll()
	reportState(vid, "launching", "")

	err := func() error {
		// verify / repair files quickly (downloads only what's missing)
		if err := ensureFiles(vid, v.VersionID); err != nil {
			return err
		}
		eff, err := resolveVersion(v.VersionID)
		if err != nil {
			return err
		}
		major := 8
		if eff.JavaVersion != nil && eff.JavaVersion.MajorVersion > 0 {
			major = eff.JavaVersion.MajorVersion
		}
		javaExe, err := ensureJava(vid, major)
		if err != nil {
			return err
		}

		gameDir := instanceDir(v)
		os.MkdirAll(gameDir, 0o755)
		os.MkdirAll(filepath.Join(gameDir, "mods"), 0o755)
		os.MkdirAll(filepath.Join(gameDir, "resourcepacks"), 0o755)

		_, classpath, natives := libraryJobs(eff)
		baseID := baseVanillaID(v.VersionID)
		cj := clientJarPath(baseID)
		classpath = append(classpath, cj)

		// natives extraction (legacy versions)
		nativesDir := filepath.Join(gameDir, "natives")
		if len(natives) > 0 {
			os.MkdirAll(nativesDir, 0o755)
			for _, n := range natives {
				excl := n.Exclude
				unzipFilter(n.Path, nativesDir, func(name string) bool {
					for _, e := range excl {
						if strings.HasPrefix(name, e) {
							return false
						}
					}
					return !strings.HasSuffix(name, "/")
				})
			}
		}

		ram := v.RamMB
		if ram <= 0 {
			cfgMu.Lock()
			ram = cfg.RamMB
			cfgMu.Unlock()
		}
		if ram < 512 {
			ram = 2048
		}
		cfgMu.Lock()
		nick := cfg.Nickname
		cfgMu.Unlock()
		if nick == "" {
			nick = "Player"
		}

		assetsRoot := assetsDir()
		assetsIndexName := eff.Assets
		if eff.AssetIndex != nil {
			assetsIndexName = eff.AssetIndex.ID
		}
		gameAssets := assetsRoot
		if assetsIndexName == "legacy" || assetsIndexName == "pre-1.6" {
			gameAssets = filepath.Join(assetsRoot, "virtual", assetsIndexName)
		}

		vars := map[string]string{
			"auth_player_name":  nick,
			"version_name":      v.VersionID,
			"game_directory":    gameDir,
			"assets_root":       assetsRoot,
			"assets_index_name": assetsIndexName,
			"game_assets":       gameAssets,
			"auth_uuid":         offlineUUID(nick),
			"auth_access_token": "0",
			"auth_session":      "0",
			"user_type":         "msa",
			"user_properties":   "{}",
			"version_type":      "VozduhLaucher",
			"clientid":          "vozduh",
			"auth_xuid":         "0",
			"natives_directory": nativesDir,
			"launcher_name":     "VozduhLaucher",
			"launcher_version":  "1.0",
			"classpath":         strings.Join(classpath, string(os.PathListSeparator)),
			"library_directory": librariesDir(),
			"classpath_separator": string(os.PathListSeparator),
			"resolution_width":  "1280",
			"resolution_height": "720",
			"quickPlayPath":     filepath.Join(gameDir, "quickplay.json"),
		}

		var jvmArgs []string
		jvmArgs = append(jvmArgs,
			"-Xms512M",
			"-Xmx"+strconv.Itoa(ram)+"M",
			"-XX:+UnlockExperimentalVMOptions",
			"-XX:+UseG1GC",
			"-XX:G1NewSizePercent=20",
			"-XX:G1ReservePercent=20",
			"-XX:MaxGCPauseMillis=50",
			"-XX:G1HeapRegionSize=32M",
			"-Dlog4j2.formatMsgNoLookups=true",
		)

		hasCP := false
		if eff.Arguments != nil && len(eff.Arguments.JVM) > 0 {
			for _, a := range eff.Arguments.JVM {
				if a.Plain != "" {
					jvmArgs = append(jvmArgs, substituteVars(a.Plain, vars))
					if a.Plain == "-cp" || a.Plain == "-classpath" {
						hasCP = true
					}
				} else if rulesAllow(a.Rules, nil) {
					for _, s := range a.List {
						jvmArgs = append(jvmArgs, substituteVars(s, vars))
					}
				}
			}
		}
		if !hasCP {
			jvmArgs = append(jvmArgs, "-Djava.library.path="+nativesDir, "-cp", vars["classpath"])
		}

		// logging config
		if lc, ok := eff.Logging["client"]; ok && lc.Argument != "" && lc.File.ID != "" {
			logCfg := filepath.Join(assetsDir(), "log_configs", lc.File.ID)
			if _, err := os.Stat(logCfg); err == nil {
				jvmArgs = append(jvmArgs, strings.ReplaceAll(lc.Argument, "${path}", logCfg))
			}
		}

		// local skin via authlib-injector (best effort, never blocks launch)
		if extra := maybeSkinArgs(); len(extra) > 0 {
			jvmArgs = append(jvmArgs, extra...)
		}

		var gameArgs []string
		if eff.Arguments != nil && len(eff.Arguments.Game) > 0 {
			for _, a := range eff.Arguments.Game {
				if a.Plain != "" {
					gameArgs = append(gameArgs, substituteVars(a.Plain, vars))
				} else if rulesAllow(a.Rules, nil) {
					// skip feature-gated args (demo, custom resolution, quickplay)
				}
			}
		} else if eff.MinecraftArguments != "" {
			for _, s := range strings.Fields(eff.MinecraftArguments) {
				gameArgs = append(gameArgs, substituteVars(s, vars))
			}
		}

		args := append(append([]string{}, jvmArgs...), eff.MainClass)
		args = append(args, gameArgs...)

		cmd := exec.Command(javaExe, args...)
		cmd.Dir = gameDir
		hideWindow(cmd)
		// keep sandbox JAVA_TOOL_OPTIONS etc. out
		env := os.Environ()
		var cleanEnv []string
		for _, e := range env {
			if strings.HasPrefix(e, "JAVA_TOOL_OPTIONS=") || strings.HasPrefix(e, "_JAVA_OPTIONS=") {
				continue
			}
			cleanEnv = append(cleanEnv, e)
		}
		cmd.Env = cleanEnv
		if err := cmd.Start(); err != nil {
			return err
		}
		runMu.Lock()
		runProcs[vid] = cmd
		runMu.Unlock()
		reportState(vid, "running", "")
		startedAt := time.Now()
		go func() {
			cmd.Wait()
			elapsed := int64(time.Since(startedAt).Seconds())
			runMu.Lock()
			delete(runProcs, vid)
			runMu.Unlock()
			// accumulate playtime
			cfgMu.Lock()
			if _, _, vv := findVersionLocked(vid); vv != nil && elapsed > 0 {
				vv.PlaySecs += elapsed
				saveConfigLocked()
			}
			cfgMu.Unlock()
			reportState(vid, "ready", "")
			pushStateAll()
		}()
		return nil
	}()
	if err != nil {
		reportState(vid, "error", err.Error())
	}
}
