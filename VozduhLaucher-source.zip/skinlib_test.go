package main

import (
	"testing"
	"time"
)

func TestSpecMatch(t *testing.T) {
	cases := []struct {
		spec, mc string
		want     bool
	}{
		{"1.21.4", "1.21.4", true},
		{"1.21.4", "1.21.5", false},
		{"1.21.6-1.21.8", "1.21.6", true},
		{"1.21.6-1.21.8", "1.21.7", true},
		{"1.21.6-1.21.8", "1.21.8", true},
		{"1.21.6-1.21.8", "1.21.5", false},
		{"1.21.6-1.21.8", "1.21.9", false},
		{"1.21-1.21.1", "1.21", true},
		{"1.21-1.21.1", "1.21.1", true},
		{"1.21-1.21.1", "1.21.2", false},
		{"1.20.-1.20.1", "1.20", true},
		{"1.20.-1.20.1", "1.20.1", true},
		{"1.20.-1.20.1", "1.20.2", false},
		{"26.1-26.1.2", "26.1", true},
		{"26.1-26.1.2", "26.1.1", true},
		{"26.1-26.1.2", "26.1.2", true},
		{"26.1-26.1.2", "26.2", false},
		{"1.16.5", "1.16.5", true},
		{"1.16.5", "1.16.4", false},
	}
	for _, c := range cases {
		if got := specMatch(c.spec, c.mc); got != c.want {
			t.Errorf("specMatch(%q,%q)=%v want %v", c.spec, c.mc, got, c.want)
		}
	}
}

func TestSkinLibFind(t *testing.T) {
	// inject a fake library resembling the real repo
	skinLibCache.Lock()
	skinLibCache.entries = []skinEntry{
		{"fabric", "1.21.4", "Tl skins and cape/Fabric/fabric 1.21.4/mod.jar"},
		{"fabric", "1.21.6-1.21.8", "Tl skins and cape/Fabric/fabric 1.21.6-1.21.8/mod.jar"},
		{"forge", "1.12.2", "Tl skins and cape/Forge/forge 1.12.2/mod.jar"},
	}
	skinLibCache.at = time.Now()
	skinLibCache.Unlock()

	if _, ok := skinLibFind("fabric", "1.21.7"); !ok {
		t.Error("fabric 1.21.7 should match the range")
	}
	if _, ok := skinLibFind("fabric", "1.14.2"); ok {
		t.Error("fabric 1.14.2 should NOT be in the library")
	}
	if _, ok := skinLibFind("forge", "1.12.2"); !ok {
		t.Error("forge 1.12.2 should match")
	}
	if _, ok := skinLibFind("vanilla", "1.21.4"); ok {
		t.Error("vanilla is never supported")
	}
	if got := rawGitHubURL("Persik1232155/Tl_skins-lib-", "main", "Tl skins and cape/Fabric/fabric 1.21.4/mod.jar"); got != "https://raw.githubusercontent.com/Persik1232155/Tl_skins-lib-/main/Tl%20skins%20and%20cape/Fabric/fabric%201.21.4/mod.jar" {
		t.Errorf("rawGitHubURL=%s", got)
	}
}
