package main

import (
	"embed"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
)

//go:embed ui/index.html ui/icon.png ui/fonts
var uiFS embed.FS

// ---------- SSE hub ----------

var sse struct {
	sync.Mutex
	clients map[chan []byte]bool
}

func broadcast(v any) {
	b, _ := json.Marshal(v)
	sse.Lock()
	for ch := range sse.clients {
		select {
		case ch <- b:
		default:
		}
	}
	sse.Unlock()
}

func statePayload() map[string]any {
	cfgMu.Lock()
	cc := cfg
	cc.Fields = append([]Field{}, cfg.Fields...)
	cfgMu.Unlock()
	return map[string]any{
		"type":   "full",
		"config": cc,
		"states": getRunStates(),
	}
}

func pushStateAll() { broadcast(statePayload()) }

// ---------- lifecycle ----------

var lastPing struct {
	sync.Mutex
	t time.Time
}

func touchPing() {
	lastPing.Lock()
	lastPing.t = time.Now()
	lastPing.Unlock()
}

func watchdog(devMode bool) {
	if devMode {
		return
	}
	lastPing.Lock()
	lastPing.t = time.Now().Add(90 * time.Second) // startup grace
	lastPing.Unlock()
	for {
		time.Sleep(5 * time.Second)
		lastPing.Lock()
		idle := time.Since(lastPing.t)
		lastPing.Unlock()
		if idle > 25*time.Second && !anyGameRunning() {
			os.Exit(0)
		}
	}
}

// ---------- helpers ----------

func jsonBody(r *http.Request, v any) error {
	defer r.Body.Close()
	return json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(v)
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, err error) {
	w.WriteHeader(400)
	writeJSON(w, map[string]string{"error": err.Error()})
}

var nickRe = regexp.MustCompile(`^[A-Za-zА-Яа-яЁё0-9_\-. ]{1,16}$`)

// ---------- router ----------

func buildMux() *http.ServeMux {
	mux := http.NewServeMux()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		b, _ := uiFS.ReadFile("ui/index.html")
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(b)
	})
	mux.HandleFunc("/icon.png", func(w http.ResponseWriter, r *http.Request) {
		b, _ := uiFS.ReadFile("ui/icon.png")
		w.Header().Set("Content-Type", "image/png")
		w.Write(b)
	})
	mux.HandleFunc("/fonts/", func(w http.ResponseWriter, r *http.Request) {
		name := strings.TrimPrefix(r.URL.Path, "/fonts/")
		if strings.Contains(name, "/") || strings.Contains(name, "..") {
			http.NotFound(w, r)
			return
		}
		b, err := uiFS.ReadFile("ui/fonts/" + name)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "font/ttf")
		w.Header().Set("Cache-Control", "max-age=86400")
		w.Write(b)
	})

	mux.HandleFunc("/api/ident", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]string{"app": "vozduhlaucher"})
	})

	mux.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) {
		touchPing()
		w.WriteHeader(204)
	})

	mux.HandleFunc("/api/events", func(w http.ResponseWriter, r *http.Request) {
		fl, ok := w.(http.Flusher)
		if !ok {
			http.Error(w, "no sse", 500)
			return
		}
		w.Header().Set("Content-Type", "text/event-stream")
		w.Header().Set("Cache-Control", "no-cache")
		ch := make(chan []byte, 64)
		sse.Lock()
		if sse.clients == nil {
			sse.clients = map[chan []byte]bool{}
		}
		sse.clients[ch] = true
		sse.Unlock()
		defer func() {
			sse.Lock()
			delete(sse.clients, ch)
			sse.Unlock()
		}()
		// initial full state
		b, _ := json.Marshal(statePayload())
		fmt.Fprintf(w, "data: %s\n\n", b)
		fl.Flush()
		touchPing()
		for {
			select {
			case msg := <-ch:
				fmt.Fprintf(w, "data: %s\n\n", msg)
				fl.Flush()
			case <-time.After(10 * time.Second):
				fmt.Fprint(w, ": ka\n\n")
				fl.Flush()
			case <-r.Context().Done():
				return
			}
			touchPing()
		}
	})

	mux.HandleFunc("/api/state", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, statePayload())
	})

	mux.HandleFunc("/api/nickname", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ Name string }
		if err := jsonBody(r, &req); err != nil {
			writeErr(w, err)
			return
		}
		req.Name = strings.TrimSpace(req.Name)
		if !nickRe.MatchString(req.Name) {
			writeErr(w, fmt.Errorf("bad nickname"))
			return
		}
		cfgMu.Lock()
		cfg.Nickname = req.Name
		cfg.FirstRun = false
		saveConfigLocked()
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/theme", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ Theme string }
		jsonBody(r, &req)
		if req.Theme != "black" && req.Theme != "dark" && req.Theme != "light" {
			writeErr(w, fmt.Errorf("bad theme"))
			return
		}
		cfgMu.Lock()
		cfg.Theme = req.Theme
		saveConfigLocked()
		cfgMu.Unlock()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/ram", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ MB int }
		jsonBody(r, &req)
		if req.MB < 512 || req.MB > 65536 {
			writeErr(w, fmt.Errorf("bad ram"))
			return
		}
		cfgMu.Lock()
		cfg.RamMB = req.MB
		saveConfigLocked()
		cfgMu.Unlock()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/snowspeed", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ Speed float64 }
		jsonBody(r, &req)
		if req.Speed < 0 || req.Speed > 5 {
			writeErr(w, fmt.Errorf("bad speed"))
			return
		}
		cfgMu.Lock()
		cfg.SnowSpeed = req.Speed
		saveConfigLocked()
		cfgMu.Unlock()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/field/rename", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ FieldID, Name string }
		jsonBody(r, &req)
		req.Name = strings.TrimSpace(req.Name)
		if req.Name == "" || len(req.Name) > 24 {
			writeErr(w, fmt.Errorf("bad name"))
			return
		}
		cfgMu.Lock()
		for i := range cfg.Fields {
			if cfg.Fields[i].ID == req.FieldID {
				cfg.Fields[i].Name = req.Name
			}
		}
		saveConfigLocked()
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/loaderversions", func(w http.ResponseWriter, r *http.Request) {
		loader := r.URL.Query().Get("loader")
		list, err := listVersionsForLoader(loader)
		if err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, list)
	})

	mux.HandleFunc("/api/version/add", func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			FieldID, Loader, MC string
			Vozduhan            bool
		}
		if err := jsonBody(r, &req); err != nil {
			writeErr(w, err)
			return
		}
		loaderNames := map[string]string{"fabric": "Fabric", "forge": "Forge", "neoforge": "NeoForge",
			"quilt": "Quilt", "liteloader": "LiteLoader", "vanilla": "Vanilla"}
		ln, ok := loaderNames[req.Loader]
		if !ok || req.MC == "" {
			writeErr(w, fmt.Errorf("bad request"))
			return
		}
		withClient := req.Vozduhan && vozduhanSupported(req.Loader, req.MC)
		name := uniqueInstanceName(ln + " " + req.MC)
		v := Version{ID: newID(), Name: name, Loader: req.Loader, MC: req.MC}
		cfgMu.Lock()
		added := false
		for i := range cfg.Fields {
			if cfg.Fields[i].ID == req.FieldID {
				cfg.Fields[i].Versions = append(cfg.Fields[i].Versions, v)
				added = true
			}
		}
		if added {
			saveConfigLocked()
		}
		cfgMu.Unlock()
		if !added {
			writeErr(w, fmt.Errorf("field not found"))
			return
		}
		os.MkdirAll(filepath.Join(instancesDir(), name), 0o755)
		pushStateAll()
		go doInstallVersion(v.ID, withClient)
		writeJSON(w, v)
	})

	mux.HandleFunc("/api/vozduhan/supported", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, vozduhanCompat)
	})

	mux.HandleFunc("/api/version/vozduhan", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		v := versionSnapshot(req.VID)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		if !vozduhanSupported(v.Loader, v.MC) {
			writeErr(w, fmt.Errorf("VozduhanClient недоступен для этой версии"))
			return
		}
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" || st == "installing" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		go installVozduhanClient(req.VID)
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/skins/status", func(w http.ResponseWriter, r *http.Request) {
		v := versionSnapshot(r.URL.Query().Get("vid"))
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		writeJSON(w, map[string]bool{
			"supported": skinLibSupported(v.Loader, v.MC),
			"installed": isSkinInstalled(v),
		})
	})

	mux.HandleFunc("/api/version/skins/remove", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		if err := removeSkinLib(req.VID); err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/skins", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		v := versionSnapshot(req.VID)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		if !skinLibSupported(v.Loader, v.MC) {
			writeErr(w, fmt.Errorf("на эту версию нету скинов"))
			return
		}
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" || st == "installing" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		go installSkinLib(req.VID)
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/vozduhan/status", func(w http.ResponseWriter, r *http.Request) {
		v := versionSnapshot(r.URL.Query().Get("vid"))
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		writeJSON(w, map[string]bool{
			"supported": vozduhanSupported(v.Loader, v.MC),
			"installed": isVozduhanInstalled(v),
		})
	})

	mux.HandleFunc("/api/version/vozduhan/remove", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		if err := removeVozduhanClient(req.VID); err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/remove", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" || st == "installing" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		var dir string
		cfgMu.Lock()
		f, vi, v := findVersionLocked(req.VID)
		if v != nil {
			dir = instanceDir(v)
			f.Versions = append(f.Versions[:vi], f.Versions[vi+1:]...)
			saveConfigLocked()
		}
		cfgMu.Unlock()
		if dir != "" {
			go os.RemoveAll(dir)
		}
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/rename", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID, Name string }
		jsonBody(r, &req)
		req.Name = sanitizeName(req.Name)
		if req.Name == "" || len(req.Name) > 40 {
			writeErr(w, fmt.Errorf("bad name"))
			return
		}
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		cfgMu.Lock()
		_, _, v := findVersionLocked(req.VID)
		if v == nil {
			cfgMu.Unlock()
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		oldName := v.Name
		newName := req.Name
		if newName != oldName {
			if _, err := os.Stat(filepath.Join(instancesDir(), newName)); err == nil {
				cfgMu.Unlock()
				writeErr(w, fmt.Errorf("name exists"))
				return
			}
			if err := os.Rename(filepath.Join(instancesDir(), oldName), filepath.Join(instancesDir(), newName)); err != nil {
				if os.IsNotExist(err) {
					os.MkdirAll(filepath.Join(instancesDir(), newName), 0o755)
				} else {
					cfgMu.Unlock()
					writeErr(w, err)
					return
				}
			}
			v.Name = newName
			saveConfigLocked()
		}
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/ram", func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			VID string
			MB  int
		}
		jsonBody(r, &req)
		if req.MB != 0 && (req.MB < 512 || req.MB > 65536) {
			writeErr(w, fmt.Errorf("bad ram"))
			return
		}
		cfgMu.Lock()
		_, _, v := findVersionLocked(req.VID)
		if v != nil {
			v.RamMB = req.MB
			saveConfigLocked()
		}
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/move", func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			VID     string
			ToField string
			ToIndex int
		}
		jsonBody(r, &req)
		cfgMu.Lock()
		f, vi, v := findVersionLocked(req.VID)
		if v == nil {
			cfgMu.Unlock()
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		vv := *v
		f.Versions = append(f.Versions[:vi], f.Versions[vi+1:]...)
		placed := false
		for i := range cfg.Fields {
			if cfg.Fields[i].ID == req.ToField {
				idx := req.ToIndex
				if idx < 0 {
					idx = 0
				}
				if idx > len(cfg.Fields[i].Versions) {
					idx = len(cfg.Fields[i].Versions)
				}
				vs := cfg.Fields[i].Versions
				vs = append(vs[:idx], append([]Version{vv}, vs[idx:]...)...)
				cfg.Fields[i].Versions = vs
				placed = true
			}
		}
		if !placed { // put back
			f.Versions = append(f.Versions, vv)
		}
		saveConfigLocked()
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/swap", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ A, B string }
		jsonBody(r, &req)
		cfgMu.Lock()
		fa, ia, va := findVersionLocked(req.A)
		fb, ib, vb := findVersionLocked(req.B)
		if va == nil || vb == nil {
			cfgMu.Unlock()
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		fa.Versions[ia], fb.Versions[ib] = *vb, *va
		saveConfigLocked()
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/openfolder", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID, Which string }
		jsonBody(r, &req)
		v := versionSnapshot(req.VID)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		dir := instanceDir(v)
		switch req.Which {
		case "mods":
			dir = filepath.Join(dir, "mods")
		case "resourcepacks":
			dir = filepath.Join(dir, "resourcepacks")
		}
		os.MkdirAll(dir, 0o755)
		openFolder(dir)
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/fix", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		if versionSnapshot(req.VID) == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		go fixInstance(req.VID)
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/launch", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID string }
		jsonBody(r, &req)
		st := getRunStates()[req.VID]
		if st == "running" || st == "launching" || st == "installing" {
			writeErr(w, fmt.Errorf("busy"))
			return
		}
		go doLaunch(req.VID)
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/image", func(w http.ResponseWriter, r *http.Request) {
		r.ParseMultipartForm(16 << 20)
		vid := r.FormValue("vid")
		file, hdr, err := r.FormFile("file")
		if err != nil {
			writeErr(w, err)
			return
		}
		defer file.Close()
		v := versionSnapshot(vid)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		ext := strings.ToLower(filepath.Ext(hdr.Filename))
		if ext != ".png" && ext != ".jpg" && ext != ".jpeg" && ext != ".webp" && ext != ".gif" {
			writeErr(w, fmt.Errorf("bad image"))
			return
		}
		os.MkdirAll(instanceDir(v), 0o755)
		name := "tile" + ext
		dst := filepath.Join(instanceDir(v), name)
		out, err := os.Create(dst)
		if err != nil {
			writeErr(w, err)
			return
		}
		io.Copy(out, file)
		out.Close()
		cfgMu.Lock()
		_, _, vv := findVersionLocked(vid)
		if vv != nil {
			vv.Image = name
			saveConfigLocked()
		}
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/instimg/", func(w http.ResponseWriter, r *http.Request) {
		vid := strings.TrimPrefix(r.URL.Path, "/instimg/")
		v := versionSnapshot(vid)
		if v == nil || v.Image == "" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Cache-Control", "no-cache")
		http.ServeFile(w, r, filepath.Join(instanceDir(v), v.Image))
	})

	mux.HandleFunc("/api/skin", func(w http.ResponseWriter, r *http.Request) {
		r.ParseMultipartForm(8 << 20)
		model := r.FormValue("model")
		if model != "slim" {
			model = "classic"
		}
		file, _, err := r.FormFile("file")
		if err != nil {
			writeErr(w, err)
			return
		}
		defer file.Close()
		os.MkdirAll(launcherRoot(), 0o755)
		dst := filepath.Join(launcherRoot(), "skin.png")
		out, err := os.Create(dst)
		if err != nil {
			writeErr(w, err)
			return
		}
		io.Copy(out, file)
		out.Close()
		cfgMu.Lock()
		cfg.Skin = "skin.png"
		cfg.SkinModel = model
		saveConfigLocked()
		cfgMu.Unlock()
		pushStateAll()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/skinfile", func(w http.ResponseWriter, r *http.Request) {
		p := skinPath()
		if p == "" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Cache-Control", "no-cache")
		http.ServeFile(w, r, p)
	})

	mux.HandleFunc("/api/modrinth/search", func(w http.ResponseWriter, r *http.Request) {
		vid := r.URL.Query().Get("vid")
		ctype := r.URL.Query().Get("type")
		q := r.URL.Query().Get("q")
		v := versionSnapshot(vid)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		res, err := mrSearch(q, ctype, v.MC, v.Loader)
		if err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, res)
	})

	mux.HandleFunc("/api/modrinth/popular", func(w http.ResponseWriter, r *http.Request) {
		hits, err := mrPopular()
		if err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, hits)
	})

	mux.HandleFunc("/api/modrinth/project", func(w http.ResponseWriter, r *http.Request) {
		id := r.URL.Query().Get("id")
		if id == "" {
			writeErr(w, fmt.Errorf("no id"))
			return
		}
		p, err := mrProjectInfo(id)
		if err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, p)
	})

	mux.HandleFunc("/api/version/installed", func(w http.ResponseWriter, r *http.Request) {
		v := versionSnapshot(r.URL.Query().Get("vid"))
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		items, err := listInstalled(v, r.URL.Query().Get("type"))
		if err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, items)
	})

	mux.HandleFunc("/api/version/content/delete", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID, Type, File string }
		jsonBody(r, &req)
		v := versionSnapshot(req.VID)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		if err := deleteInstalled(v, req.Type, req.File); err != nil {
			writeErr(w, err)
			return
		}
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/version/content/update", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID, Type, File string }
		jsonBody(r, &req)
		v := versionSnapshot(req.VID)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		go func() {
			broadcast(map[string]any{"type": "contentupdate", "file": req.File, "status": "updating"})
			err := updateInstalled(v, req.Type, req.File)
			status := "done"
			msg := ""
			if err != nil {
				status = "error"
				msg = err.Error()
			}
			broadcast(map[string]any{"type": "contentupdate", "file": req.File, "status": status, "msg": msg})
		}()
		writeJSON(w, map[string]bool{"ok": true})
	})

	mux.HandleFunc("/api/modrinth/install", func(w http.ResponseWriter, r *http.Request) {
		var req struct{ VID, ProjectID, Type string }
		jsonBody(r, &req)
		v := versionSnapshot(req.VID)
		if v == nil {
			writeErr(w, fmt.Errorf("not found"))
			return
		}
		go func() {
			broadcast(map[string]any{"type": "modinstall", "vid": req.VID, "project": req.ProjectID, "status": "installing"})
			err := mrInstall(v, req.ProjectID, req.Type)
			status := "done"
			msg := ""
			if err != nil {
				status = "error"
				msg = err.Error()
			}
			broadcast(map[string]any{"type": "modinstall", "vid": req.VID, "project": req.ProjectID, "status": status, "msg": msg})
		}()
		writeJSON(w, map[string]bool{"ok": true})
	})

	return mux
}
