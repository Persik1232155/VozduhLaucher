package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func writeVJ(t *testing.T, id, content string) {
	t.Helper()
	p := filepath.Join(versionsDir(), id, id+".json")
	os.MkdirAll(filepath.Dir(p), 0o755)
	if err := os.WriteFile(p, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestResolveAndArgs(t *testing.T) {
	rootDir = t.TempDir()
	writeVJ(t, "1.21.1", `{
	  "id":"1.21.1","type":"release","mainClass":"net.minecraft.client.main.Main",
	  "assets":"17",
	  "assetIndex":{"id":"17","url":"https://x/17.json","sha1":"","size":1},
	  "downloads":{"client":{"url":"https://x/client.jar","sha1":"abc","size":10}},
	  "javaVersion":{"component":"java-runtime-delta","majorVersion":21},
	  "arguments":{
	    "game":["--username","${auth_player_name}",{"rules":[{"action":"allow","features":{"is_demo_user":true}}],"value":"--demo"}],
	    "jvm":[{"rules":[{"action":"allow","os":{"name":"windows"}}],"value":"-XX:+Win"},
	           {"rules":[{"action":"allow","os":{"name":"osx"}}],"value":"-XstartOnFirstThread"},
	           "-Djava.library.path=${natives_directory}","-cp","${classpath}"]
	  },
	  "libraries":[
	    {"name":"org.lwjgl:lwjgl:3.3.3","downloads":{"artifact":{"path":"org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3.jar","url":"https://x/l.jar","sha1":"","size":1}}},
	    {"name":"org.lwjgl:lwjgl:3.3.3:natives-windows","rules":[{"action":"allow","os":{"name":"windows"}}],"downloads":{"artifact":{"path":"org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3-natives-windows.jar","url":"https://x/lnw.jar","sha1":"","size":1}}},
	    {"name":"com.mojang:oldlib:1.0","downloads":{"artifact":{"path":"com/mojang/oldlib/1.0/oldlib-1.0.jar","url":"https://x/old1.jar","sha1":"","size":1}}},
	    {"name":"only.mac:thing:1","rules":[{"action":"allow","os":{"name":"osx"}}],"downloads":{"artifact":{"path":"only/mac/thing/1/thing-1.jar","url":"https://x/mac.jar","sha1":"","size":1}}}
	  ]
	}`)
	writeVJ(t, "fabric-loader-0.16.9-1.21.1", `{
	  "id":"fabric-loader-0.16.9-1.21.1","inheritsFrom":"1.21.1","type":"release",
	  "mainClass":"net.fabricmc.loader.impl.launch.knot.KnotClient",
	  "arguments":{"game":[],"jvm":["-DFabricMcEmu= net.minecraft.client.main.Main "]},
	  "libraries":[
	    {"name":"net.fabricmc:fabric-loader:0.16.9","url":"https://maven.fabricmc.net/"},
	    {"name":"com.mojang:oldlib:2.0","url":"https://maven.fabricmc.net/"}
	  ]
	}`)

	eff, err := resolveVersion("fabric-loader-0.16.9-1.21.1")
	if err != nil {
		t.Fatal(err)
	}
	if eff.MainClass != "net.fabricmc.loader.impl.launch.knot.KnotClient" {
		t.Errorf("mainClass=%s", eff.MainClass)
	}
	if eff.Downloads["client"] == nil || eff.Downloads["client"].URL != "https://x/client.jar" {
		t.Error("client jar lost in merge")
	}
	if eff.JavaVersion == nil || eff.JavaVersion.MajorVersion != 21 {
		t.Error("javaVersion lost")
	}

	jobs, cp, natives := libraryJobs(eff)
	cpj := strings.Join(cp, "|")
	if !strings.Contains(cpj, "fabric-loader") {
		t.Error("fabric-loader missing from classpath")
	}
	// child version of duplicate lib must win
	if !strings.Contains(cpj, "oldlib-2.0") || strings.Contains(cpj, "oldlib-1.0") {
		t.Errorf("dedupe failed: %s", cpj)
	}
	// natives-windows classifier must not collide with main lwjgl jar
	if !strings.Contains(cpj, "lwjgl-3.3.3.jar") || !strings.Contains(cpj, "natives-windows") {
		t.Errorf("lwjgl entries wrong: %s", cpj)
	}
	// mac-only lib excluded
	if strings.Contains(cpj, "thing-1") {
		t.Error("osx lib not filtered")
	}
	if len(natives) != 0 {
		t.Error("modern format should have no legacy natives")
	}
	if len(jobs) == 0 {
		t.Error("no download jobs")
	}

	// base id + client jar path
	if base := baseVanillaID("fabric-loader-0.16.9-1.21.1"); base != "1.21.1" {
		t.Errorf("base=%s", base)
	}

	// offline uuid matches vanilla algorithm (known value for "Notch" offline)
	if u := offlineUUID("Notch"); u != "b50ad385-829d-3141-a216-7e7d7539ba7f" {
		t.Errorf("offlineUUID=%s", u)
	}
}

func TestArgSubstitution(t *testing.T) {
	vars := map[string]string{"auth_player_name": "Персик_123", "classpath": "a;b"}
	if s := substituteVars("--username ${auth_player_name}", vars); s != "--username Персик_123" {
		t.Error(s)
	}
}

func TestNeoMCFor(t *testing.T) {
	cases := map[string]string{"21.1.77": "1.21.1", "20.2.88": "1.20.2", "26.2.3-beta": "1.26.2", "21.0.1": "1.21"}
	for in, want := range cases {
		if got := neoMCFor(in); got != want {
			t.Errorf("neoMCFor(%s)=%s want %s", in, got, want)
		}
	}
}

func TestMavenPath(t *testing.T) {
	if p := mavenPath("net.fabricmc:fabric-loader:0.16.9"); p != "net/fabricmc/fabric-loader/0.16.9/fabric-loader-0.16.9.jar" {
		t.Error(p)
	}
	if p := mavenPath("com.mumfrey:liteloader:1.12.2"); p != "com/mumfrey/liteloader/1.12.2/liteloader-1.12.2.jar" {
		t.Error(p)
	}
}
